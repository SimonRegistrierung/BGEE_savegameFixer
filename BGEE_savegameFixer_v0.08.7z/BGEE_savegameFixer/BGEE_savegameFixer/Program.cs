﻿using System;
using System.Collections;
using System.IO;
using BGEE_savegameFixer;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        internal static byte[] gamByteArray;
        internal static byte[] savByteArray;

        // GAME OBJECTS
        
        internal static GamHeader gamHeader;
        internal static ArrayList gamNpcsParty;
        internal static ArrayList gamCreStructsParty;
        internal static ArrayList gamNpcsNonParty;
        internal static ArrayList gamCreStructsNonParty;
        internal static ArrayList gamVars;
        internal static ArrayList gamJournalEntries;
        internal static GamFamiliarInfo gamFamiliarInfo;
        internal static ArrayList gamStoredLocations;
        internal static ArrayList gamPocketPlaneInfos;

        internal static GamNpc currentGamNpc;
        internal static GamCreStruct currentGamCreStruct;
        internal static GamVar currentGamVar;
        internal static GamJournalEntry currentGamJournalEntry;
        internal static GamStoredLocationInfo currentGamStoredLocationInfo;
        internal static GamStoredLocationInfo currentGamPocketPlaneInfo;

        // SAVE OBJECTS
        
        internal static SavHeader savHeader;
        internal static ArrayList savElements;
        
        internal static SavElement CurrentSavElement;

        public static void Main(string[] args)
        {
            FileInfo[] gamFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "gam");
            FileInfo[] savFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "sav");
            
            // /////////// //
            // GAM EDITING //
            // /////////// //
            
            // REPLACE RINGITF WITH RING02
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //     for (int i = 0; i < gamCreStructsParty.Count; i++)
            //     {
            //         currentGamCreStruct = (GamCreStruct)gamCreStructsParty[i];
            //         for (int j = currentGamCreStruct.creItems.Count - 1; j >= 0; j--)
            //         {
            //             CreItem currentCreItem = (CreItem)currentGamCreStruct.creItems[j];
            //             if (currentCreItem.resource.Contains("RINGITF"))
            //             {
            //                 currentCreItem.resource = "RING02" + new string(new char[2]);
            //                 Console.WriteLine("FOUND RINGITF");
            //             }
            //         }
            //     }
            //     FileOperations.WriteFile(
            //         gamHeader,
            //         gamNpcsParty,
            //         gamCreStructsParty,
            //         gamNpcsNonParty,
            //         gamCreStructsNonParty,
            //         gamVars,
            //         gamJournalEntries,
            //         gamFamiliarInfo,
            //         gamStoredLocations,
            //         gamPocketPlaneInfos,
            //         gamFile.FullName);
            // }
            
            // REMOVE WAND OF APPRENTI & DECREASE WAND CHARGES
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //     for (int i = 0; i < gamCreStructsParty.Count; i++)
            //     {
            //         currentGamCreStruct = (GamCreStruct)gamCreStructsParty[i];
            //         for (int j = currentGamCreStruct.creItems.Count - 1; j >= 0; j--)
            //         {
            //             CreItem currentCreItem = (CreItem)currentGamCreStruct.creItems[j];
            //             if (currentCreItem.resource.Contains("WAND"))
            //             {
            //                 currentCreItem.charges1 = 15;
            //                 Console.WriteLine("FOUND WANDXX");
            //             }
            //
            //             if (currentCreItem.resource.Contains("MH#WAND1"))
            //             {
            //                 currentCreItem.charges2 = 15;
            //                 Console.WriteLine("FOUND MH#WAND1");
            //             }
            //             if (currentCreItem.resource.Contains("WAND18"))
            //             {
            //                 currentCreItem.charges2 = 15;
            //                 Console.WriteLine("FOUND WAND18");
            //             }
            //
            //             if (currentCreItem.resource.Contains("WAND15"))
            //             {
            //                 currentGamCreStruct.creItems.RemoveAt(j);
            //                 Console.WriteLine("FOUND WAND15");
            //             }
            //         }
            //     }
            //     FileOperations.WriteFile(
            //         gamHeader,
            //         gamNpcsParty,
            //         gamCreStructsParty,
            //         gamNpcsNonParty,
            //         gamCreStructsNonParty,
            //         gamVars,
            //         gamJournalEntries,
            //         gamFamiliarInfo,
            //         gamStoredLocations,
            //         gamPocketPlaneInfos,
            //         gamFile.FullName);
            // }
            
            // DELETE SPELLS FOR BAELOTH
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //
            //     int baelothIndex = FindPartyCreIndex(@"*AELOTH");
            //     try
            //     {
            //         currentGamCreStruct = (GamCreStruct) gamCreStructsParty[baelothIndex];
            //
            //         currentGamCreStruct.creKnownSpells.RemoveAt(4);
            //         currentGamCreStruct.creKnownSpells.RemoveAt(3);
            //
            //         gamCreStructsParty[baelothIndex] = currentGamCreStruct;
            //
            //         FileOperations.WriteFile(
            //             gamHeader,
            //             gamNpcsParty,
            //             gamCreStructsParty,
            //             gamNpcsNonParty,
            //             gamCreStructsNonParty,
            //             gamVars,
            //             gamJournalEntries,
            //             gamFamiliarInfo,
            //             gamStoredLocations,
            //             gamPocketPlaneInfos,
            //             gamFile.FullName);
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            
            // FIX WRONG EFFECTS FOR ITEMS
            
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //
            //     int minscIndex = FindPartyCreIndex(@"*INSC");
            //     try
            //     {
            //         currentGamCreStruct = (GamCreStruct) gamCreStructsParty[minscIndex];
            //
            //         for (int i = 0; i < currentGamCreStruct.creEffects.Count; i++)
            //         {
            //             CreEffect currentEffect = (CreEffect) currentGamCreStruct.creEffects[i];
            //             if ((currentEffect.opcode == 206 || currentEffect.opcode == 83) && currentEffect.timingMode != 2)
            //             {
            //                 Console.WriteLine(currentEffect.duration);
            //                 currentGamCreStruct.creEffects.RemoveAt(i);
            //                 currentGamCreStruct.creHeader.effectsCount--;
            //                 currentGamCreStruct.creHeader.effectsOffset -= 264;
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //             }
            //         }
            //
            //         gamCreStructsParty[minscIndex] = currentGamCreStruct;
            //
            //         FileOperations.WriteFile(
            //             gamHeader,
            //             gamNpcsParty,
            //             gamCreStructsParty,
            //             gamNpcsNonParty,
            //             gamCreStructsNonParty,
            //             gamVars,
            //             gamJournalEntries,
            //             gamFamiliarInfo,
            //             gamStoredLocations,
            //             gamPocketPlaneInfos,
            //             gamFile.FullName);
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            
            // REMOVE QUICK BUFFER
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //
            //     int simonIndex = FindPartyCreIndex(@"*IMONEUS");
            //     try
            //     {
            //         currentGamCreStruct = (GamCreStruct) gamCreStructsParty[simonIndex];
            //
            //         for (int i = 0; i < currentGamCreStruct.creKnownSpells.Count; i++)
            //         {
            //             CreKnownSpell currentSpell = (CreKnownSpell) currentGamCreStruct.creKnownSpells[i];
            //             if (currentSpell.resource.Equals("SPZI003"))
            //             {
            //                 currentGamCreStruct.creKnownSpells.RemoveAt(i);
            //                 currentGamCreStruct.creHeader.knownSpellsCount--;
            //                 currentGamCreStruct.creHeader.knownSpellsOffset -= CreKnownSpell.size;
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //             }
            //         }
            //         
            //         for (int i = 0; i < currentGamCreStruct.creMemorizedSpells.Count; i++)
            //         {
            //             CreMemorizedSpell currentSpell = (CreMemorizedSpell) currentGamCreStruct.creMemorizedSpells[i];
            //             if (currentSpell.resource.Equals("SPZI003"))
            //             {
            //                 currentGamCreStruct.creMemorizedSpells.RemoveAt(i);
            //                 currentGamCreStruct.creHeader.memoSpellsCount--;
            //                 currentGamCreStruct.creHeader.memoSpellsOffset -= CreMemorizedSpell.size;
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //             }
            //         }
            //
            //         gamCreStructsParty[simonIndex] = currentGamCreStruct;
            //
            //         FileOperations.WriteFile(
            //             gamHeader,
            //             gamNpcsParty,
            //             gamCreStructsParty,
            //             gamNpcsNonParty,
            //             gamCreStructsNonParty,
            //             gamVars,
            //             gamJournalEntries,
            //             gamFamiliarInfo,
            //             gamStoredLocations,
            //             gamPocketPlaneInfos,
            //             gamFile.FullName);
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            
            //
            // FIX PROFICIENCIES 
            //
            // foreach (FileInfo gamFile in gamFileInfos)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //     
            //     try
            //     {
            //         for (int j = 0; j < gamCreStructsParty.Count; j++)
            //         {
            //             currentGamCreStruct = (GamCreStruct) gamCreStructsParty[j];
            //
            //             for (int i = 0; i < currentGamCreStruct.creEffects.Count; i++)
            //             {
            //                 CreEffect currentEffect = (CreEffect) currentGamCreStruct.creEffects[i];
            //                 if (currentEffect.opcode == 233 && currentEffect.target != 1)
            //                 {
            //                     Console.WriteLine(currentGamCreStruct.creHeader.name);
            //                     currentEffect.target = 1;
            //                     currentGamCreStruct.creEffects[i] = currentEffect;
            //                 }
            //             }
            //
            //             gamCreStructsParty[j] = currentGamCreStruct;
            //
            //             FileOperations.WriteFile(
            //                 gamHeader,
            //                 gamNpcsParty,
            //                 gamCreStructsParty,
            //                 gamNpcsNonParty,
            //                 gamCreStructsNonParty,
            //                 gamVars,
            //                 gamJournalEntries,
            //                 gamFamiliarInfo,
            //                 gamStoredLocations,
            //                 gamPocketPlaneInfos,
            //                 gamFile.FullName);
            //         }
            //         
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            // /////////// //
            // SAV EDITING //
            // /////////// //
            
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0)
            //         {
            //             found = true;
            //             foreach (AreActor areActor in savElement.areActors)
            //             {
            //                 areActor.offsetCreStructure = 0;
            //             }
            //
            //             savElement.savCreStructs = new ArrayList();
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }

            // ADAPT EXP POINTS FOR GAMAZ
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.name.Contains("RSGAMAZ"))
            //                 {
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 1000;
            //                     break;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // ADAPT EXP POINTS FOR REVENANT
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.name.Contains("REVEN"))
            //                 {
            //                     Console.WriteLine("FOUND REVENANT");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 1000;
            //                     break;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // ADAPT EXP POINTS FOR DURLAG TOWER
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.name.Contains("DOPDUR"))
            //                 {
            //                     Console.WriteLine("FOUND DURLAG");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //                 else if (areActor.name.Contains("DOPISL"))
            //                 {
            //                     Console.WriteLine("FOUND ISLANNE");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //                 else if (areActor.name.Contains("DOPKIE"))
            //                 {
            //                     Console.WriteLine("FOUND KIEL");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //                 else if (areActor.name.Contains("DOPFUE"))
            //                 {
            //                     Console.WriteLine("FOUND FUERNEBOL");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // ADAPT EXP POINTS FOR GREATER WYVERN IN DURLAG'S TOWER
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.altActorName.Contains("Greater Wyvern"))
            //                 {
            //                     Console.WriteLine("FOUND WYVERN");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // ADAPT EXP POINTS FOR GRAEL IN DURLAG'S TOWER
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.altActorName.Contains("Grael"))
            //                 {
            //                     Console.WriteLine("FOUND GRAEL");
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // ADAPT EXP POINTS FOR SLYTHE & KRYSTIN
            // foreach (FileInfo savFileInfo in savFileInfos)
            // {
            //     Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
            //     
            //     CreateSavObjects(savFileInfo.FullName);
            //
            //     Boolean found = false;
            //
            //     foreach (SavElement savElement in savElements)
            //     {
            //         savElement.Decompress();
            //         if (savElement.fileType == 0) // if are file
            //         {
            //             int index = 0;
            //             foreach (AreActor areActor in savElement.areActors) // search all areActors
            //             {
            //                 if (areActor.altActorName.Contains("Slythe") || areActor.altActorName.Contains("Krystin"))
            //                 {
            //                     Console.WriteLine("FOUND " + areActor.altActorName);
            //                     SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
            //                     found = true;
            //                     currentSavCreStruct.creHeader.xpKill = 2000;
            //                 }
            //
            //                 index++;
            //             }
            //         }
            //         savElement.Compress();
            //     }
            //     
            //     if (found)
            //     {
            //         FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
            //     }
            // }
            
            // TAMOKO
            foreach (FileInfo savFileInfo in savFileInfos)
            {
                Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
                
                CreateSavObjects(savFileInfo.FullName);
            
                Boolean found = false;
            
                foreach (SavElement savElement in savElements)
                {
                    savElement.Decompress();
                    if (savElement.fileType == 0) // if are file
                    {
                        int index = 0;
                        foreach (AreActor areActor in savElement.areActors) // search all areActors
                        {
                            if (areActor.altActorName.Contains("Tamoko"))
                            {
                                Console.WriteLine("FOUND " + areActor.altActorName);
                                SavCreStruct currentSavCreStruct = (SavCreStruct)savElement.savCreStructs[index];
                                found = true;
                                currentSavCreStruct.creHeader.xpKill = 2000;
                            }
            
                            index++;
                        }
                    }
                    savElement.Compress();
                }
                
                if (found)
                {
                    FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
                }
            }
        }
    }
}