﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class AreTrigger
    {
        internal static int size = 196; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal short regionType;
        internal short boundingBoxLeft;
        internal short boundingBoxTop;
        internal short boundingBoxRight;
        internal short boundingBoxBottom;
        internal short numVertices;
        internal int firstVertexIndex;
        internal int triggerValue;
        internal int cursorNumber;
        internal String destArea;
        internal String entraceName;
        internal int flags;
        internal int infoPointText;
        internal short trapDetectionDifficulty;
        internal short trapRemovalDifficulty;
        internal short isTrapped;
        internal short isTrapDetected;
        internal short launchPointX;
        internal short launchPointY;
        internal String key;
        internal String script;
        internal short activationPointX;
        internal short activationPointY;
        internal byte[] unknown1;

        internal AreTrigger(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            name = ConvertToStringData(32);
            regionType = ConvertToShortData();
            boundingBoxLeft = ConvertToShortData();
            boundingBoxTop = ConvertToShortData();
            boundingBoxRight = ConvertToShortData();
            boundingBoxBottom = ConvertToShortData();
            numVertices = ConvertToShortData();
            firstVertexIndex = ConvertToIntData();
            triggerValue = ConvertToIntData();
            cursorNumber = ConvertToIntData();
            destArea = ConvertToStringData(8);
            entraceName = ConvertToStringData(32);
            flags = ConvertToIntData();
            infoPointText = ConvertToIntData();
            trapDetectionDifficulty = ConvertToShortData();
            trapRemovalDifficulty = ConvertToShortData();
            isTrapped = ConvertToShortData();
            isTrapDetected = ConvertToShortData();
            launchPointX = ConvertToShortData();
            launchPointY = ConvertToShortData();
            key = ConvertToStringData(8);
            script = ConvertToStringData(8);
            activationPointX = ConvertToShortData();
            activationPointY = ConvertToShortData();
            unknown1 = ConvertToUnknownData(60);

            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(regionType);
            CopyBytesToArray(boundingBoxLeft);
            CopyBytesToArray(boundingBoxTop);
            CopyBytesToArray(boundingBoxRight);
            CopyBytesToArray(boundingBoxBottom);
            CopyBytesToArray(numVertices);
            CopyBytesToArray(firstVertexIndex);
            CopyBytesToArray(triggerValue);
            CopyBytesToArray(cursorNumber);
            CopyBytesToArray(destArea);
            CopyBytesToArray(entraceName);
            CopyBytesToArray(flags);
            CopyBytesToArray(infoPointText);
            CopyBytesToArray(trapDetectionDifficulty);
            CopyBytesToArray(trapRemovalDifficulty);
            CopyBytesToArray(isTrapped);
            CopyBytesToArray(isTrapDetected);
            CopyBytesToArray(launchPointX);
            CopyBytesToArray(launchPointY);
            CopyBytesToArray(key);
            CopyBytesToArray(script);
            CopyBytesToArray(activationPointX);
            CopyBytesToArray(activationPointY);
            CopyBytesToArray(unknown1);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}