﻿using System;
using System.Collections;
using System.IO;
using System.Threading;
using BGEE_savegameFixer;

namespace BGEE_savegameFixer
{
    internal class FileOperations
    {
        internal static Boolean CheckFilePath(String path)
        {
            if (!File.Exists(path))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal static void CheckBasePath(String path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        internal static byte[] ReadFile(String filePath)
        {
            if (File.Exists(filePath))
            {
                // NEW METHOD: ALL AT ONCE
                return File.ReadAllBytes(filePath);
            }
            else
            {
                // Console.WriteLine("File doesn't exist!");
                return null;
            }
        }

        internal static void SaveByteFile(String path, byte[] byteFile)
        {
            File.WriteAllBytes(path, byteFile);
        }
        
        internal static String ReadFileAsString(String filePath)
        {
            if (File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            else
            {
                throw new FileNotFoundException();
            }
        }

        internal static FileInfo[] GetAllSavegames(String savegameLocation, String fileExt)
        {
            DirectoryInfo directoryInfo = new DirectoryInfo(savegameLocation);
            return directoryInfo.GetFiles("*." + fileExt, SearchOption.AllDirectories);
        }

        internal static void WriteFile(String filePath, byte[] byteFile)
        {
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(String sourcePath, String destPath)
        {
            File.Copy(sourcePath, destPath, true);
        }
        
        internal static void WriteFileAsString(String fileContent, String filePath)
        {
            File.WriteAllText(filePath, fileContent);
        }

        internal static int[] GetStructOffsets(ArrayList list, int begin)
        {
            int[] offsets = new int[list.Count];
            int index = 0;
            int offset = begin;
            foreach (GamCreStruct creStruct in list)
            {
                offsets[index] = offset;
                offset += creStruct.size;
                index++;
            }

            return offsets;
        }

        internal static void WriteFile(SavHeader header, ArrayList files, String filePath)
        {
            Console.WriteLine(filePath);
            int fileSizeSum = 0;
            foreach (SavElement file in files)
            {
                fileSizeSum += file.size;
                // Console.WriteLine(file.size);
            }

            byte[] byteFile = new byte[
                SavHeader.size + 
                fileSizeSum 
            ];
            
            int offset = 0;
            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += SavHeader.size;

            foreach (SavElement file in files)
            {
                bytes = file.GetByteData();
                // Console.WriteLine(file.size);
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += file.size;
            }
            
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(byte[] content, String filePath)
        {
            // Console.WriteLine(filePath);
            File.WriteAllBytes(filePath, content);
        }

        internal static void WriteFile(GamHeader header, ArrayList partyNpcs, ArrayList partyCreStructs, ArrayList nonPartyNpcs, ArrayList nonPartyCreStructs, ArrayList vars, ArrayList journalEntries, GamFamiliarInfo familiarInfo, ArrayList storedLocations, ArrayList pocketPlaneInfos, String filePath)
        {
            int partyCreStructsSize = 0;
            foreach (GamCreStruct partyCreStruct in partyCreStructs)
            {
                partyCreStruct.UpdateSizeAndOffsets();
                partyCreStructsSize += partyCreStruct.size;
            }
            int nonPartyCreStructsSize = 0;
            foreach (GamCreStruct nonPartyCreStruct in nonPartyCreStructs)
            {
                nonPartyCreStruct.UpdateSizeAndOffsets();
                nonPartyCreStructsSize += nonPartyCreStruct.size;
            }
            
            
            byte[] byteFile = new byte[
                GamHeader.size + 
                partyNpcs.Count * GamNpc.size + 
                partyCreStructsSize + 
                nonPartyNpcs.Count * GamNpc.size +
                nonPartyCreStructsSize + 
                vars.Count * GamVar.size + 
                journalEntries.Count * GamJournalEntry.size +
                GamFamiliarInfo.size +
                storedLocations.Count * GamStoredLocationInfo.size + 
                pocketPlaneInfos.Count * GamStoredLocationInfo.size 
            ];
            byte[] bytes;
            int offset = GamHeader.size;

            int[] structOffsets = GetStructOffsets(partyCreStructs, offset + partyNpcs.Count * GamNpc.size);
            int index = 0;
            header.offsetNpcStructsParty = offset;
            header.countNpcStructsParty = partyNpcs.Count;
            // Console.WriteLine("offsetNpcStructsParty: " + header.offsetNpcStructsParty);
            // Console.WriteLine("countNpcStructsParty: " + header.countNpcStructsParty);
            if (header.countNpcStructsParty > 0)
            {
                foreach (GamNpc partyNpc in partyNpcs)
                {
                    partyNpc.offsetToCreResourceData = structOffsets[index];
                    // Console.WriteLine(partyNpc.charName + "..." + partyNpc.offsetToCreResourceData);
                    bytes = partyNpc.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += GamNpc.size;
                    index++;
                }
                foreach (GamCreStruct partyCreStruct in partyCreStructs)
                {
                    bytes = partyCreStruct.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += partyCreStruct.size;
                }
            }
            
            structOffsets = GetStructOffsets(nonPartyCreStructs, offset + nonPartyNpcs.Count * GamNpc.size);
            // Console.WriteLine(structOffsets.Length);
            index = 0;
            header.offsetNpcStructsNonParty = offset;
            header.countNpcStructsNonParty = nonPartyNpcs.Count;
            // Console.WriteLine("offsetNpcStructsNonParty: " + header.offsetNpcStructsNonParty);
            // Console.WriteLine("countNpcStructsNonParty: " + header.countNpcStructsNonParty);
            if (header.countNpcStructsNonParty > 0)
            {
                foreach (GamNpc nonPartyNpc in nonPartyNpcs)
                {
                    nonPartyNpc.offsetToCreResourceData = structOffsets[index];
                    // Console.WriteLine(nonPartyNpc.charName + "..." + nonPartyNpc.offsetToCreResourceData);
                    bytes = nonPartyNpc.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += GamNpc.size;
                    index++;
                }
                foreach (GamCreStruct nonPartyCreStruct in nonPartyCreStructs)
                {
                    bytes = nonPartyCreStruct.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += nonPartyCreStruct.size;
                }
            }

            header.offsetGlobalNamespaceVars = offset;
            header.countGlobalNamespaceVars = vars.Count;
            // Console.WriteLine("offsetGlobalNamespaceVars: " + header.offsetGlobalNamespaceVars);
            // Console.WriteLine("countGlobalNamespaceVars: " + header.countGlobalNamespaceVars);
            foreach (GamVar var in vars)
            {
                bytes = var.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamVar.size;
            }
            
            header.offsetJournalEntries = offset;
            header.countJournalEntries = journalEntries.Count;
            // Console.WriteLine("offsetJournalEntries: " + header.offsetJournalEntries);
            // Console.WriteLine("countJournalEntries: " + header.countJournalEntries);
            foreach (GamJournalEntry journalEntry in journalEntries)
            {
                bytes = journalEntry.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamJournalEntry.size;
            }
            
            header.offsetFamiliarInfo = offset;
            // Console.WriteLine("offsetFamiliarInfo: " + header.offsetFamiliarInfo);
            bytes = familiarInfo.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += GamFamiliarInfo.size;
            
            header.offsetStoredLocations = offset;
            header.countStoredLocations = storedLocations.Count;
            // Console.WriteLine("offsetStoredLocations: " + header.offsetStoredLocations);
            // Console.WriteLine("countStoredLocations: " + header.countStoredLocations);
            foreach (GamStoredLocationInfo storedLocation in storedLocations)
            {
                bytes = storedLocation.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamStoredLocationInfo.size;
            }
            
            header.offsetPocketPlaneLocations = offset;
            header.countPocketPlaneLocations = pocketPlaneInfos.Count;
            // Console.WriteLine("offsetPocketPlaneLocations: " + header.offsetPocketPlaneLocations);
            // Console.WriteLine("countPocketPlaneLocations: " + header.countPocketPlaneLocations);
            foreach (GamStoredLocationInfo pocketPlaneInfo in pocketPlaneInfos)
            {
                bytes = pocketPlaneInfo.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamStoredLocationInfo.size;
            }
            
            // finally copy the header file with previously changed offsets/counts
            offset = 0;
            bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            File.WriteAllBytes(filePath, byteFile);
        }
    }
}