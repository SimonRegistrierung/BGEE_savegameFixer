﻿using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;
using BGEE_savegameFixer;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        
        internal static short GetBitfieldShort(int[] pos)
        {
            BitArray bitArray = new BitArray(16, false);

            foreach (int p in pos)
            {
                bitArray[p] = true;
            }

            byte[] newByte = new byte[2];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt16(newByte, 0);
        }

        internal static int FindPartyCreIndex(String findChar)
        {
            for (int i = 0; i < gamNpcsParty.Count; i++)
            {
                currentGamNpc = (GamNpc) gamNpcsParty[i];
                if (currentGamNpc.charName.Contains(findChar))
                {
                    return i;
                }
            }
            return -1;
        }
        
        internal static int FindNonPartyCreIndex(String findChar)
        {
            for (int i = 0; i < gamNpcsNonParty.Count; i++)
            {
                currentGamNpc = (GamNpc) gamNpcsNonParty[i];
                if (currentGamNpc.charName.Contains(findChar))
                {
                    return i;
                }
            }
            return -1;
        }
        
        internal static void CreateGamObjects(String path)
        {
            gamByteArray = FileOperations.ReadFile(path);
            
            gamHeader = new GamHeader(gamByteArray);

            int offset;
            
            //create PARTY NPC
            offset = gamHeader.offsetNpcStructsParty;
            gamNpcsParty = new ArrayList();
            if (gamHeader.countNpcStructsParty > 0)
            {
                for (int i = 0; i < gamHeader.countNpcStructsParty; i++)
                {
                    // Console.WriteLine(i + "..." + gamHeader.countNpcStructsParty);
                    currentGamNpc = new GamNpc(gamByteArray, offset);
                    gamNpcsParty.Add(currentGamNpc);
                    offset += GamNpc.size;
                }
            }
            
            //create PARTY NPC CRE STRUCTS
            gamCreStructsParty = new ArrayList();
            if (gamNpcsParty.Count > 0)
            {
                for (int i = 0; i < gamNpcsParty.Count; i++)
                {
                    currentGamNpc = (GamNpc)gamNpcsParty[i];
                    // Console.WriteLine(currentGamNpc.offsetToCreResourceData);
                    gamCreStructsParty.Add(new GamCreStruct(gamByteArray, currentGamNpc.offsetToCreResourceData));
                }
            }

            //create NON PARTY NPC
            offset = gamHeader.offsetNpcStructsNonParty;
            gamNpcsNonParty = new ArrayList();
            if (gamHeader.countNpcStructsNonParty > 0)
            {
                for (int i = 0; i < gamHeader.countNpcStructsNonParty; i++)
                {
                    currentGamNpc = new GamNpc(gamByteArray, offset);
                    gamNpcsNonParty.Add(currentGamNpc);
                    offset += GamNpc.size;
                }
            }
            
            //create NON PARTY NPC CRE STRUCTS
            gamCreStructsNonParty = new ArrayList();
            if (gamNpcsNonParty.Count > 0)
            {
                for (int i = 0; i < gamNpcsNonParty.Count; i++)
                {
                    currentGamNpc = (GamNpc)gamNpcsNonParty[i];
                    gamCreStructsNonParty.Add(new GamCreStruct(gamByteArray, currentGamNpc.offsetToCreResourceData));
                }
            }
            
            //create GAME VARS
            offset = gamHeader.offsetGlobalNamespaceVars;
            gamVars = new ArrayList();
            if (gamHeader.countGlobalNamespaceVars > 0)
            {
                for (int i = 0; i < gamHeader.countGlobalNamespaceVars; i++)
                {
                    currentGamVar = new GamVar(gamByteArray, offset);
                    gamVars.Add(currentGamVar);
                    offset += GamVar.size;
                    // Console.WriteLine(currentGamVar.name);
                }
            }
            
            //create GAME JOURNAL ENTRIES
            offset = gamHeader.offsetJournalEntries;
            gamJournalEntries = new ArrayList();
            if (gamHeader.countJournalEntries > 0)
            {
                for (int i = 0; i < gamHeader.countJournalEntries; i++)
                {
                    currentGamJournalEntry = new GamJournalEntry(gamByteArray, offset);
                    gamJournalEntries.Add(currentGamJournalEntry);
                    offset += GamJournalEntry.size;
                    // Console.WriteLine(currentGamJournalEntry.journalText);
                }
            }
            
            //create GAM FAMILIAR INFO
            offset = gamHeader.offsetFamiliarInfo;
            gamFamiliarInfo = new GamFamiliarInfo(gamByteArray, offset);
            
            //create GAME STORED LOCATIONS
            offset = gamHeader.offsetStoredLocations;
            gamStoredLocations = new ArrayList();
            if (gamHeader.countStoredLocations > 0)
            {
                for (int i = 0; i < gamHeader.countStoredLocations; i++)
                {
                    currentGamStoredLocationInfo = new GamStoredLocationInfo(gamByteArray, offset);
                    gamStoredLocations.Add(currentGamStoredLocationInfo);
                    offset += GamStoredLocationInfo.size;
                    // Console.WriteLine(currentGamStoredLocationInfo.area);
                }
            }
            
            //create GAME POCKET PLANE LOCATIONS
            offset = gamHeader.offsetPocketPlaneLocations;
            gamPocketPlaneInfos = new ArrayList();
            if (gamHeader.countPocketPlaneLocations > 0)
            {
                for (int i = 0; i < gamHeader.countPocketPlaneLocations; i++)
                {
                    currentGamPocketPlaneInfo = new GamStoredLocationInfo(gamByteArray, offset);
                    gamPocketPlaneInfos.Add(currentGamPocketPlaneInfo);
                    offset += GamStoredLocationInfo.size;
                    // Console.WriteLine(currentGamStoredLocationInfo.area);
                }
            }
        }
        
        internal static void CreateSavObjects(String path)
        {
            savByteArray = FileOperations.ReadFile(path);
            savHeader = new SavHeader(savByteArray);
            int offset = SavHeader.size;

            savElements = new ArrayList();
            int index = 0;
            while (savByteArray.Length > offset)
            {
                CurrentSavElement = new SavElement(savByteArray, offset, path, index);
                savElements.Add(CurrentSavElement);
                offset += CurrentSavElement.size;
                CurrentSavElement.Decompress();
                index++;
            }
        }
    }
}