﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    internal class TohEntry
    {
        internal static int size = 8;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;

        internal int strRefNum;
        internal int offsetStrRefSection; //Start offset of the override string (relative to the start of the Strref entries section)

        internal TohEntry(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            strRefNum = ConvertToIntData();
            offsetStrRefSection = ConvertToIntData();
            
            size = baseOffset;
            
            this.byteArray = null; // clear the byteList;
        }
    
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(strRefNum);
            CopyBytesToArray(offsetStrRefSection);

            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}