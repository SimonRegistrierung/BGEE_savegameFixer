﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using Ionic.Zlib;

namespace BGEE_savegameFixer
{
    internal class SavElement
    {
        // STO OBJECTS
        
        internal StoHeader stoHeader;
        internal ArrayList stoItemsPurchased;
        internal ArrayList stoItemsForSale;
        internal ArrayList stoDrinks;
        internal ArrayList stoCures;
        
        internal int currentStoItemPurchased;
        internal StoItem currentStoItemForSale;
        internal StoDrink currentStoDrink;
        internal StoCure currentStoCure;
        
        // ARE OBJECTS
        
        internal AreHeader areHeader;
        internal ArrayList areActors;
        internal ArrayList areTriggers;
        internal ArrayList areSpawnPoints;
        internal ArrayList areEntrances;
        internal ArrayList areContainers;
        internal ArrayList areItems;
        internal ArrayList areVertices;
        internal ArrayList areAmbients;
        internal ArrayList areVariables;
        internal byte[] areExploredBitmasks;
        internal ArrayList areDoors;
        internal ArrayList areAnimations;
        internal ArrayList areTiledObjects;
        internal AreSong areSong;
        internal AreRestEncounter areRestEncounter;
        internal ArrayList areAutomapNotes;
        internal ArrayList areProjectileTraps;
        
        internal AreActor currentAreActor;
        internal AreTrigger currentAreTrigger;
        internal AreSpawnPoint currentAreSpawnPoint;
        internal AreEntrance currentAreEntrance;
        internal AreContainer currentAreContainer;
        internal AreItem currentAreItem;
        internal AreVertex currentAreVertex;
        internal AreAmbient currentAreAmbient;
        internal AreVariable currentAreVariable;
        internal AreDoor currentAreDoor;
        internal AreAnimation currentAreAnimation;
        internal AreTiledObject currentAreTiledObject;
        internal AreAutomapNote currentAreAutomapNote;
        internal AreProjectileTrap currentAreProjectileTrap;
        
        // CRE OBJECTS
        
        internal ArrayList savCreStructs;
        internal SavCreStruct currentSavCreStruct;
        
        // WMP OBJECTS
        
        internal WmpHeader wmpHeader;
        internal ArrayList wmpWorldMapEntries;
        internal ArrayList wmpAreaEntries;
        internal ArrayList wmpAreaLinkEntries;
        
        internal WmpWorldMapEntry currentWmpWorldMapEntry;
        internal WmpAreaEntry currentWmpAreaEntry;
        internal WmpAreaLinkEntry currentWmpAreaLinkEntry;
        
        // TOH OBJECTS

        internal TohHeader tohHeader;
        internal ArrayList tohEntries;
        internal String tohStringSection;
        
        internal TohEntry currentTohEntry;

        /// CUSTOM OBJECTS
        
        internal int size = 0;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;

        /// OBJECTS CREATED FROM RAW GAM/SAV FILE
        
        internal int lengthFilename;
        internal String filename;
        internal int decompressedDataLength;
        internal int compressedDataLength;
        internal byte[] compressedData;

        // CUSTOM OBJECTS CREATED DURING INITIALIZATION
        
        internal byte[] decompressedData;
        internal int fileType; // 0 = are, 1 = sto, 2 = wmp, 3 = toh

        private MemoryStream memStream;
        private ZlibStream zipStream;

        internal SavElement(byte[] byteArray, int offset, String path, int index)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            lengthFilename = ConvertToIntData();
            filename = ConvertToStringData(lengthFilename);
            
            decompressedDataLength = ConvertToIntData();
            compressedDataLength = ConvertToIntData();
            compressedData = ConvertToUnknownData(compressedDataLength);

            UpdateSize(); // size is all vars + compressed data size (before decompressing it)
            decompressedData = new byte[decompressedDataLength];

            // Console.WriteLine("lengthFilename: " + lengthFilename);
            // Console.WriteLine("filename: " + filename);
            // Console.WriteLine("decompressedDataLength: " + decompressedDataLength);
            // Console.WriteLine("compressedDataLength: " + compressedDataLength);
            // Console.WriteLine("size: " + compressedDataLength);
            // Console.WriteLine("---------EOF----------");

            this.byteArray = null; // clear the byteList;
        }
        
        internal void Decompress()
        {
            memStream = new MemoryStream(compressedData);
            MemoryStream resultStream = new MemoryStream();
            
            zipStream = new ZlibStream(memStream, CompressionMode.Decompress, false);
            zipStream.CopyTo(resultStream);
            decompressedData = resultStream.ToArray();

            CreateObjects();
        }

        internal void Compress()
        {
            CreateByteData();
            
            // Console.WriteLine("compressedDataLength " + compressedDataLength);
            // Console.WriteLine("decompressedDataLength " + decompressedDataLength);

            memStream = new MemoryStream();
            zipStream = new ZlibStream(memStream, CompressionMode.Compress, CompressionLevel.BestCompression, false);
            zipStream.Write(decompressedData, 0, decompressedData.Length);
            zipStream.Close();

            compressedData = memStream.ToArray();
            compressedDataLength = compressedData.Length; // UPDATE COMPRESSED DATA LENGTH
            
            // Console.WriteLine("compressedDataLength " + compressedDataLength);
            // Console.WriteLine("decompressedDataLength " + decompressedDataLength);
            
            UpdateSize();
        }

        internal void UpdateSize()
        {
            size = 4 + lengthFilename + 4 + 4 + compressedDataLength; // size is all vars + compressed data size (before decompressing it)
        }
        
        internal void CreateByteData()
        {
            // Console.WriteLine("decompressedData.Length " + decompressedData.Length);
            if (fileType == 0)
            {
                CreateAreByteFile();
            }
            else if (fileType == 1)
            {
                CreateStoByteFile();
            }
            else if (fileType == 2)
            {
                CreateWmpByteFile();
            }
            else if (fileType == 3)
            {
                CreateTohByteFile();
            }
            decompressedDataLength = decompressedData.Length;
            // Console.WriteLine("decompressedData.Length " + decompressedData.Length);
        }

        internal void CreateObjects()
        {
            String headerId = Encoding.ASCII.GetString(decompressedData, 0, 4);
            // Console.WriteLine(headerId);
            if (headerId.Contains("AREA"))
            {
                fileType = 0;
                CreateAreObjects();
            }
            else if (headerId.Contains("STOR"))
            {
                fileType = 1;
                CreateStoObjects();
            }
            else if (headerId.Contains("WMAP"))
            {
                fileType = 2;
                CreateWmpObjects();
            }
            else if (headerId.Contains("TLK"))
            {
                fileType = 3;
                CreateTohObjects();
            }
        }
    
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            UpdateSize();
            // Console.WriteLine(size);
            // Console.WriteLine(4+lengthFilename+4+4+compressedData.Length);
            
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(lengthFilename);
            CopyBytesToArray(filename);
            CopyBytesToArray(decompressedDataLength);
            CopyBytesToArray(compressedDataLength);
            CopyBytesToArray(compressedData);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }

        internal void CreateTohObjects()
        {
            // get header
            tohHeader = new TohHeader(decompressedData);
            int offset = tohHeader.offsetStrRefs;
            // int offset = TohHeader.size;

            tohEntries = new ArrayList();
            for (int i = 0; i < tohHeader.numStrRefs; i++)
            {
                // Console.WriteLine(offset);
                currentTohEntry = new TohEntry(decompressedData, offset);
                tohEntries.Add(currentTohEntry);
                offset += TohEntry.size;
            }
        }
        
        internal void CreateWmpObjects()
        {
            // get header
            wmpHeader = new WmpHeader(decompressedData);
            int offset;

            // get world map entries
            offset = wmpHeader.worldmapEntriesOffset;
            wmpWorldMapEntries = new ArrayList();
            for (int i = 0; i < wmpHeader.worldmapEntriesCount; i++)
            {
                currentWmpWorldMapEntry = new WmpWorldMapEntry(decompressedData, offset);
                wmpWorldMapEntries.Add(currentWmpWorldMapEntry);
                //currentWorldmapEntry.PrintValues();
                offset += WmpWorldMapEntry.size;
            }
            
            // get area entries
            wmpAreaEntries = new ArrayList();
            foreach (WmpWorldMapEntry worldmapEntry in wmpWorldMapEntries)
            {
                for (int i = 0; i < worldmapEntry.areaEntriesCount; i++)
                {
                    currentWmpAreaEntry = new WmpAreaEntry(decompressedData, offset);
                    wmpAreaEntries.Add(currentWmpAreaEntry);
                    //currentAreaEntry.PrintValues();
                    offset += WmpAreaEntry.size;
                }
            }
            
            // get area link entries
            wmpAreaLinkEntries = new ArrayList();
            foreach (WmpAreaEntry areaEntry in wmpAreaEntries)
            {
                int numberOfAreaLinkEntries = areaEntry.linkCountNorth + areaEntry.linkCountWest +
                                              areaEntry.linkCountSouth + areaEntry.linkCountEast;
                for (int i = 0; i < numberOfAreaLinkEntries; i++) // get number of area link entries
                {
                    currentWmpAreaLinkEntry = new WmpAreaLinkEntry(decompressedData, offset);
                    wmpAreaLinkEntries.Add(currentWmpAreaLinkEntry);
                    offset += WmpAreaLinkEntry.size;
                    //currentAreaLinkEntry.PrintValues();
                }
            }
        }
        
        internal void CreateStoObjects()
        {
            // get header
            stoHeader = new StoHeader(decompressedData);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleOffset);
            // Console.WriteLine(currentStoFileInfo.Name + " " + stoHeader.curesForSaleCount);
            int offset;
            
            // get drinks
            offset = stoHeader.drinksForSaleOffset;
            stoDrinks = new ArrayList();
            for (int i = 0; i < stoHeader.drinksForSaleCount; i++)
            {
                currentStoDrink = new StoDrink(decompressedData, offset);
                stoDrinks.Add(currentStoDrink);
                // currentWorldmapEntry.PrintValues();
                offset += StoDrink.size;
            }
            
            // get items for sale
            offset = stoHeader.itemsForSaleOffset;
            stoItemsForSale = new ArrayList();
            for (int i = 0; i < stoHeader.itemsForSaleCount; i++)
            {
                currentStoItemForSale = new StoItem(decompressedData, offset);
                // Console.WriteLine(currentStoItemForSale.itmFileName);
                stoItemsForSale.Add(currentStoItemForSale);
                //currentWorldmapEntry.PrintValues();
                offset += StoItem.size;
            }
            
            // get cures
            offset = stoHeader.curesForSaleOffset;
            stoCures = new ArrayList();
            for (int i = 0; i < stoHeader.curesForSaleCount; i++)
            {
                currentStoCure = new StoCure(decompressedData, offset);
                stoCures.Add(currentStoCure);
                //currentWorldmapEntry.PrintValues();
                offset += StoCure.size;
            }
            
            // get items for purchase
            offset = stoHeader.itemsPurchasedOffset;
            stoItemsPurchased = new ArrayList();
            for (int i = 0; i < stoHeader.itemsPurchasedCount; i++)
            {
                currentStoItemPurchased = BitConverter.ToInt32(decompressedData, offset);
                // Console.WriteLine(currentStoItemPurchased);
                stoItemsPurchased.Add(currentStoItemPurchased);
                //currentWorldmapEntry.PrintValues();
                offset += 4;
            }
        }
        
        internal void CreateAreObjects()
        {
            // create header
            areHeader = new AreHeader(decompressedData);
            
            int offset;
        
            //
            offset = areHeader.offsetActors;
            areActors = new ArrayList();
            for (int i = 0; i < areHeader.numberOfActors; i++)
            {
                currentAreActor = new AreActor(decompressedData, offset);
                areActors.Add(currentAreActor);
                offset += AreActor.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            
            // NOW GET THE ACTORS CRE FILES
            savCreStructs = new ArrayList();
            foreach (AreActor areActor in areActors)
            {
                if (areActor.offsetCreStructure > 0)
                {
                    currentSavCreStruct = new SavCreStruct(decompressedData, areActor.offsetCreStructure);
                    // Console.WriteLine("currentSavCreStruct.creHeader.version " + currentSavCreStruct.creHeader.version);
                    // Console.WriteLine(areActor.name);
                    savCreStructs.Add(currentSavCreStruct);
                }
            }
            
            // Console.WriteLine(currentAreFileInfo + " : " + areActors.Count);
            //
            offset = areHeader.offsetTriggers;
            areTriggers = new ArrayList();
            for (int i = 0; i < areHeader.numberOfTrigger; i++)
            {
                currentAreTrigger = new AreTrigger(decompressedData, offset);
                areTriggers.Add(currentAreTrigger);
                offset += AreTrigger.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetSpawnPoints;
            areSpawnPoints = new ArrayList();
            for (int i = 0; i < areHeader.numberOfSpawnPoints; i++)
            {
                currentAreSpawnPoint = new AreSpawnPoint(decompressedData, offset);
                areSpawnPoints.Add(currentAreSpawnPoint);
                offset += AreSpawnPoint.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetEntrances;
            areEntrances = new ArrayList();
            for (int i = 0; i < areHeader.numberOfEntraces; i++)
            {
                currentAreEntrance = new AreEntrance(decompressedData, offset);
                areEntrances.Add(currentAreEntrance);
                offset += AreEntrance.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetContainers;
            areContainers = new ArrayList();
            for (int i = 0; i < areHeader.numberOfContainers; i++)
            {
                currentAreContainer = new AreContainer(decompressedData, offset);
                areContainers.Add(currentAreContainer);
                offset += AreContainer.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetItems;
            areItems = new ArrayList();
            for (int i = 0; i < areHeader.numberOfItems; i++)
            {
                currentAreItem = new AreItem(decompressedData, offset);
                areItems.Add(currentAreItem);
                offset += AreItem.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetVertices;
            areVertices = new ArrayList();
            for (int i = 0; i < areHeader.numberOfVertices; i++)
            {
                currentAreVertex = new AreVertex(decompressedData, offset);
                areVertices.Add(currentAreVertex);
                offset += AreVertex.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetAmbients;
            areAmbients = new ArrayList();
            for (int i = 0; i < areHeader.numberOfAmbients; i++)
            {
                currentAreAmbient = new AreAmbient(decompressedData, offset);
                areAmbients.Add(currentAreAmbient);
                offset += AreAmbient.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            
            offset = areHeader.offsetVariables;
            areVariables = new ArrayList();
            for (int i = 0; i < areHeader.numberOfVariables; i++)
            {
                currentAreVariable = new AreVariable(decompressedData, offset);
                areVariables.Add(currentAreVariable);
                offset += AreVariable.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetDoors;
            areExploredBitmasks = new byte[areHeader.exploredBitmaskSize];
            Buffer.BlockCopy(decompressedData, areHeader.exploredBitmaskOffset, areExploredBitmasks, 0, areHeader.exploredBitmaskSize);
            //
            offset = areHeader.offsetDoors;
            areDoors = new ArrayList();
            for (int i = 0; i < areHeader.numberOfDoors; i++)
            {
                currentAreDoor = new AreDoor(decompressedData, offset);
                areDoors.Add(currentAreDoor);
                offset += AreDoor.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetAnimations;
            areAnimations = new ArrayList();
            for (int i = 0; i < areHeader.numberOfAnimations; i++)
            {
                currentAreAnimation = new AreAnimation(decompressedData, offset);
                areAnimations.Add(currentAreAnimation);
                offset += AreAnimation.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetTiledObjects;
            areTiledObjects = new ArrayList();
            for (int i = 0; i < areHeader.numberOfTiledObjects; i++)
            {
                currentAreTiledObject = new AreTiledObject(decompressedData, offset);
                areTiledObjects.Add(currentAreTiledObject);
                offset += AreTiledObject.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            areSong = new AreSong(decompressedData, areHeader.songsOffset);
            
            // Console.WriteLine(currentAreFileInfo.Name + ":" + areSong.daySong);
            
            areRestEncounter = new AreRestEncounter(decompressedData, areHeader.restEncountersOffset);
            //
            offset = areHeader.automapNotesOffset;
            areAutomapNotes = new ArrayList();
            for (int i = 0; i < areHeader.numberOfAutomapNotes; i++)
            {
                currentAreAutomapNote = new AreAutomapNote(decompressedData, offset);
                areAutomapNotes.Add(currentAreAutomapNote);
                offset += AreAutomapNote.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
            //
            offset = areHeader.offsetProjectileTraps;
            areProjectileTraps = new ArrayList();
            for (int i = 0; i < areHeader.numberOfProjectileTraps; i++)
            {
                currentAreProjectileTrap = new AreProjectileTrap(decompressedData, offset);
                areProjectileTraps.Add(currentAreProjectileTrap);
                offset += AreProjectileTrap.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
            }
        }
        
        internal void CreateAreByteFile()
        {
            int savCreStructsSize = 0;
            foreach (SavCreStruct savCreStruct in savCreStructs)
            {
                savCreStructsSize += savCreStruct.size;
            }
            
            decompressedData = new byte[
                AreHeader.size +
                savCreStructsSize + 
                areActors.Count * AreActor.size + 
                areTriggers.Count * AreTrigger.size + 
                areSpawnPoints.Count * AreSpawnPoint.size +
                areEntrances.Count * AreEntrance.size +
                areContainers.Count * AreContainer.size +
                areItems.Count * AreItem.size +
                areVertices.Count * AreVertex.size +
                areAmbients.Count * AreAmbient.size +
                areVariables.Count * AreVariable.size +
                areExploredBitmasks.Length +
                areDoors.Count * AreDoor.size +
                areAnimations.Count * AreAnimation.size +
                areTiledObjects.Count * AreTiledObject.size +
                AreSong.size +
                AreRestEncounter.size +
                areAutomapNotes.Count * AreAutomapNote.size +
                areProjectileTraps.Count * AreProjectileTrap.size
            ];

            int offset = 0;
            byte[] tempBytes;
            offset += AreHeader.size;
            
            areHeader.songsOffset = offset;
            tempBytes = areSong.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
            offset += AreSong.size;
            
            areHeader.restEncountersOffset = offset;
            tempBytes = areRestEncounter.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
            offset += AreRestEncounter.size;
            
            areHeader.exploredBitmaskOffset = offset;
            areHeader.exploredBitmaskSize = areExploredBitmasks.Length;
            System.Buffer.BlockCopy(areExploredBitmasks, 0, decompressedData, offset, areHeader.exploredBitmaskSize);
            offset += areHeader.exploredBitmaskSize;
            
            areHeader.offsetAnimations = offset;
            areHeader.numberOfAnimations = (short)areAnimations.Count;
            foreach (AreAnimation element in areAnimations)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreAnimation.size;
            }
            
            areHeader.offsetAmbients = offset;
            areHeader.numberOfAmbients = (short)areAmbients.Count;
            foreach (AreAmbient element in areAmbients)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreAmbient.size;
            }
            
            //ADD CRE STRUCTS
            int[] creStructsOffsets = new int[savCreStructs.Count];
            int index = 0;
            foreach (SavCreStruct savCreStruct in savCreStructs)
            {
                currentSavCreStruct = (SavCreStruct)savCreStructs[index];
                creStructsOffsets[index] = offset;
                tempBytes = savCreStruct.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += tempBytes.Length;
                index++;
            }
            
            // ADD ARE CRE OBJECTS
            areHeader.offsetActors = offset;
            areHeader.numberOfActors = (short)areActors.Count;
            index = 0;
            if (savCreStructs.Count > 0)
            {
                foreach (AreActor element in areActors)
                {
                    currentSavCreStruct = (SavCreStruct) savCreStructs[index];
                    element.offsetCreStructure = creStructsOffsets[index];
                    element.sizeCreStructure = currentSavCreStruct.size;
                    tempBytes = element.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += AreActor.size;
                    index++;
                }
            }

            areHeader.offsetDoors = offset;
            areHeader.numberOfDoors = (short)areDoors.Count;
            foreach (AreDoor element in areDoors)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreDoor.size;
            }   
            
            areHeader.offsetTriggers = offset;
            areHeader.numberOfTrigger = (short)areTriggers.Count;
            foreach (AreTrigger element in areTriggers)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreTrigger.size;
            }
            
            areHeader.offsetContainers = offset;
            areHeader.numberOfContainers = (short)areContainers.Count;
            foreach (AreContainer element in areContainers)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreContainer.size;
            }
            
            areHeader.offsetVariables = offset;
            areHeader.numberOfVariables = (short)areVariables.Count;
            foreach (AreVariable element in areVariables)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreVariable.size;
            }
            
            areHeader.offsetEntrances = offset;
            areHeader.numberOfEntraces = (short)areEntrances.Count;
            foreach (AreEntrance element in areEntrances)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreEntrance.size;
            }
            
            areHeader.automapNotesOffset = offset;
            areHeader.numberOfAutomapNotes = (short)areAutomapNotes.Count;
            foreach (AreAutomapNote element in areAutomapNotes)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreAutomapNote.size;
            }
            
            areHeader.offsetSpawnPoints = offset;
            areHeader.numberOfSpawnPoints = (short)areSpawnPoints.Count;
            foreach (AreSpawnPoint element in areSpawnPoints)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreSpawnPoint.size;
            }
            
            areHeader.offsetItems = offset;
            areHeader.numberOfItems = (short)areItems.Count;
            foreach (AreItem element in areItems)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreItem.size;
            }
            
            areHeader.offsetVertices = offset;
            areHeader.numberOfVertices = (short)areVertices.Count;
            foreach (AreVertex element in areVertices)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreVertex.size;
            }
            
            areHeader.offsetTiledObjects = offset;
            areHeader.numberOfTiledObjects = (short)areTiledObjects.Count;
            foreach (AreTiledObject element in areTiledObjects)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreTiledObject.size;
            }
            
            areHeader.offsetProjectileTraps = offset;
            areHeader.numberOfProjectileTraps = (short)areProjectileTraps.Count;
            foreach (AreProjectileTrap element in areProjectileTraps)
            {
                tempBytes = element.GetByteData();
                System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                offset += AreProjectileTrap.size;
            }

            // add header with altered offsets and counts @ offset 0
            tempBytes = areHeader.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, 0, tempBytes.Length);
        }

        internal byte[] CreateCreByteFile(CreHeader creHeader, ArrayList knownSpells, ArrayList memorizedSpellsInfos, ArrayList memorizedSpells, ArrayList effects, ArrayList items, CreItemSlots itemSlots)
        {
            byte[] byteFile = new byte[
                CreHeader.size + 
                knownSpells.Count * CreKnownSpell.size + 
                memorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size + 
                memorizedSpells.Count * CreMemorizedSpell.size + 
                effects.Count * CreEffect.size + 
                items.Count * CreItem.size + 
                CreItemSlots.size
            ];
            byte[] bytes;
            int offset = CreHeader.size;

            creHeader.knownSpellsOffset = offset;
            creHeader.knownSpellsCount = knownSpells.Count;
            // Console.WriteLine(creHeader.knownSpellsCount);
            // Console.WriteLine(creHeader.knownSpellsOffset);
            if (knownSpells.Count != 0)
            {
                foreach (CreKnownSpell knownSpell in knownSpells)
                {
                    bytes = knownSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreKnownSpell.size;
                }
            }

            creHeader.spellsMemoInfoOffset = offset;
            creHeader.spellsMemoInfoCount = memorizedSpellsInfos.Count;
            // Console.WriteLine(creHeader.spellsMemoInfoOffset);
            if (memorizedSpellsInfos.Count != 0)
            {
                foreach (CreMemorizedSpellsInfo memorizedSpellsInfo in memorizedSpellsInfos)
                {
                    bytes = memorizedSpellsInfo.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpellsInfo.size;
                }
            }
            
            creHeader.memoSpellsOffset = offset;
            creHeader.memoSpellsCount = memorizedSpells.Count;
            if (memorizedSpells.Count != 0)
            {
                foreach (CreMemorizedSpell memorizedSpell in memorizedSpells)
                {
                    bytes = memorizedSpell.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreMemorizedSpell.size;
                }
            }
            
            creHeader.effectsOffset = offset;
            creHeader.effectsCount = effects.Count;
            if (effects.Count != 0)
            {
                foreach (CreEffect effect in effects)
                {
                    bytes = effect.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreEffect.size;
                }
            }
            
            creHeader.itemsOffset = offset;
            creHeader.itemsCount = items.Count;
            if (items.Count != 0)
            {
                foreach (CreItem item in items)
                {
                    bytes = item.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += CreItem.size;
                }
            }
            
            creHeader.itemSlotsOffset = offset;
            bytes = itemSlots.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);

            // add header with altered offsets and counts @ offset 0
            bytes = creHeader.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, 0, bytes.Length);

            return byteFile;
        }

        internal void CreateStoByteFile()
        {
            decompressedData = new byte[
                StoHeader.size +
                stoDrinks.Count * StoDrink.size + 
                stoItemsForSale.Count * StoItem.size +
                stoCures.Count * StoCure.size +
                stoItemsPurchased.Count * 4
            ];

            int offset = 0;
            byte[] tempBytes;
            offset += StoHeader.size;

            stoHeader.drinksForSaleOffset = offset;
            stoHeader.drinksForSaleCount = stoDrinks.Count;
            if (stoDrinks.Count != 0)
            {
                foreach (StoDrink drink in stoDrinks)
                {
                    tempBytes = drink.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += StoDrink.size;
                }
            }
            
            stoHeader.itemsForSaleOffset = offset;
            stoHeader.itemsForSaleCount = stoItemsForSale.Count;
            if (stoItemsForSale.Count != 0)
            {
                foreach (StoItem item in stoItemsForSale)
                {
                    tempBytes = item.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += StoItem.size;
                }
            }
            
            stoHeader.curesForSaleOffset = offset;
            stoHeader.curesForSaleCount = stoCures.Count;
            if (stoCures.Count != 0)
            {
                foreach (StoCure cure in stoCures)
                {
                    tempBytes = cure.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += StoCure.size;
                }
            }
            
            stoHeader.itemsPurchasedOffset = offset;
            stoHeader.itemsPurchasedCount = stoItemsPurchased.Count;
            if (stoItemsPurchased.Count != 0)
            {
                foreach (int item in stoItemsPurchased)
                {
                    System.Buffer.BlockCopy(BitConverter.GetBytes(item), 0, decompressedData, offset, 4);
                    offset += 4;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            tempBytes = stoHeader.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, 0, tempBytes.Length);
        }

        internal void CreateWmpByteFile()
        {
            decompressedData = new byte[
                WmpHeader.size + 
                wmpWorldMapEntries.Count * WmpWorldMapEntry.size + 
                wmpAreaEntries.Count * WmpAreaEntry.size + 
                wmpAreaLinkEntries.Count * WmpAreaLinkEntry.size
            ];
            
            int offset = 0;
            byte[] tempBytes;
            offset += WmpHeader.size;
            
            wmpHeader.worldmapEntriesOffset = offset;
            wmpHeader.worldmapEntriesCount = wmpWorldMapEntries.Count;
            if (wmpWorldMapEntries.Count != 0)
            {
                foreach (WmpWorldMapEntry worldmapEntry in wmpWorldMapEntries)
                {
                    tempBytes = worldmapEntry.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += WmpWorldMapEntry.size;

                    worldmapEntry.areaEntriesOffset = WmpWorldMapEntry.size * wmpWorldMapEntries.Count;
                    worldmapEntry.areaEntriesCount = wmpAreaEntries.Count;
                    worldmapEntry.areaLinkEntriesOffset = WmpWorldMapEntry.size * wmpWorldMapEntries.Count + WmpAreaEntry.size * wmpAreaEntries.Count;
                    worldmapEntry.areaLinkEntriesCount = wmpAreaLinkEntries.Count;
                }
            }

            if (wmpAreaEntries.Count != 0)
            {
                foreach (WmpAreaEntry areaEntry in wmpAreaEntries)
                {
                    tempBytes = areaEntry.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += WmpAreaEntry.size;
                }
            }
            
            if (wmpAreaLinkEntries.Count != 0)
            {
                foreach (WmpAreaLinkEntry areaLinkEntry in wmpAreaLinkEntries)
                {
                    tempBytes = areaLinkEntry.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += WmpAreaLinkEntry.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            tempBytes = wmpHeader.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, 0, tempBytes.Length);
        }
        
        internal void CreateTohByteFile()
        {
            decompressedData = new byte[
                TohHeader.size + 
                tohEntries.Count * TohEntry.size
            ];
            
            int offset = 0;
            byte[] tempBytes;
            offset += TohHeader.size;
            
            tohHeader.offsetStrRefs = offset;
            tohHeader.numStrRefs = tohEntries.Count;
            if (tohEntries.Count != 0)
            {
                foreach (TohEntry tohEntry in tohEntries)
                {
                    tempBytes = tohEntry.GetByteData();
                    System.Buffer.BlockCopy(tempBytes, 0, decompressedData, offset, tempBytes.Length);
                    offset += TohEntry.size;
                }
            }
            
            // add header with altered offsets and counts @ offset 0
            tempBytes = tohHeader.GetByteData();
            System.Buffer.BlockCopy(tempBytes, 0, decompressedData, 0, tempBytes.Length);
        }
    }
}