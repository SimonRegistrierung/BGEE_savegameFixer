﻿using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;
using BGEE_revisions;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        
        internal static short GetBitfieldShort(int[] pos)
        {
            BitArray bitArray = new BitArray(16, false);

            foreach (int p in pos)
            {
                bitArray[p] = true;
            }

            byte[] newByte = new byte[2];
                            
            bitArray.CopyTo(newByte, 0);

            return BitConverter.ToInt16(newByte, 0);
        }

        internal static int FindPartyCreIndex(String findChar)
        {
            for (int i = 0; i < gamNpcsParty.Count; i++)
            {
                currentGamNpc = (GamNpc) gamNpcsParty[i];
                if (currentGamNpc.charName.Contains(findChar))
                {
                    return i;
                }
            }
            return -1;
        }
        
        internal static void CreateGamObjects(String path)
        {
            byteArray = FileOperations.ReadFile(path + "/BALDUR.GAM");
            
            gamHeader = new GamHeader(byteArray);

            int offset;
            
            //create PARTY NPC
            offset = gamHeader.offsetNpcStructsParty;
            gamNpcsParty = new ArrayList();
            if (gamHeader.countNpcStructsParty > 0)
            {
                for (int i = 0; i < gamHeader.countNpcStructsParty; i++)
                {
                    currentGamNpc = new GamNpc(byteArray, offset);
                    gamNpcsParty.Add(currentGamNpc);
                    offset += GamNpc.size;
                }
            }
            
            //create PARTY NPC CRE STRUCTS
            gamCreStructsParty = new ArrayList();
            if (gamNpcsParty.Count > 0)
            {
                for (int i = 0; i < gamNpcsParty.Count; i++)
                {
                    currentGamNpc = (GamNpc)gamNpcsParty[i];
                    // Console.WriteLine(currentGamNpc.offsetToCreResourceData);
                    gamCreStructsParty.Add(new GamCreStruct(byteArray, currentGamNpc.offsetToCreResourceData));
                }
            }

            //create NON PARTY NPC
            offset = gamHeader.offsetNpcStructsNonParty;
            gamNpcsNonParty = new ArrayList();
            if (gamHeader.countNpcStructsNonParty > 0)
            {
                for (int i = 0; i < gamHeader.countNpcStructsNonParty; i++)
                {
                    currentGamNpc = new GamNpc(byteArray, offset);
                    gamNpcsNonParty.Add(currentGamNpc);
                    offset += GamNpc.size;
                }
            }
            
            //create NON PARTY NPC CRE STRUCTS
            gamCreStructsNonParty = new ArrayList();
            if (gamNpcsNonParty.Count > 0)
            {
                for (int i = 0; i < gamNpcsNonParty.Count; i++)
                {
                    currentGamNpc = (GamNpc)gamNpcsNonParty[i];
                    gamCreStructsNonParty.Add(new GamCreStruct(byteArray, currentGamNpc.offsetToCreResourceData));
                }
            }
            
            //create GAME VARS
            offset = gamHeader.offsetGlobalNamespaceVars;
            gamVars = new ArrayList();
            if (gamHeader.countGlobalNamespaceVars > 0)
            {
                for (int i = 0; i < gamHeader.countGlobalNamespaceVars; i++)
                {
                    currentGamVar = new GamVar(byteArray, offset);
                    gamVars.Add(currentGamVar);
                    offset += GamVar.size;
                    // Console.WriteLine(currentGamVar.name);
                }
            }
            
            //create GAME JOURNAL ENTRIES
            offset = gamHeader.offsetJournalEntries;
            gamJournalEntries = new ArrayList();
            if (gamHeader.countJournalEntries > 0)
            {
                for (int i = 0; i < gamHeader.countJournalEntries; i++)
                {
                    currentGamJournalEntry = new GamJournalEntry(byteArray, offset);
                    gamJournalEntries.Add(currentGamJournalEntry);
                    offset += GamJournalEntry.size;
                    // Console.WriteLine(currentGamJournalEntry.journalText);
                }
            }
            
            //create GAM FAMILIAR INFO
            offset = gamHeader.offsetFamiliarInfo;
            gamFamiliarInfo = new GamFamiliarInfo(byteArray, offset);
            
            //create GAME STORED LOCATIONS
            offset = gamHeader.offsetStoredLocations;
            gamStoredLocations = new ArrayList();
            if (gamHeader.countStoredLocations > 0)
            {
                for (int i = 0; i < gamHeader.countStoredLocations; i++)
                {
                    currentGamStoredLocationInfo = new GamStoredLocationInfo(byteArray, offset);
                    gamStoredLocations.Add(currentGamStoredLocationInfo);
                    offset += GamStoredLocationInfo.size;
                    // Console.WriteLine(currentGamStoredLocationInfo.area);
                }
            }
            
            //create GAME POCKET PLANE LOCATIONS
            offset = gamHeader.offsetPocketPlaneLocations;
            gamPocketPlaneInfos = new ArrayList();
            if (gamHeader.countPocketPlaneLocations > 0)
            {
                for (int i = 0; i < gamHeader.countPocketPlaneLocations; i++)
                {
                    currentGamPocketPlaneInfo = new GamStoredLocationInfo(byteArray, offset);
                    gamPocketPlaneInfos.Add(currentGamPocketPlaneInfo);
                    offset += GamStoredLocationInfo.size;
                    // Console.WriteLine(currentGamStoredLocationInfo.area);
                }
            }
        }
    }
}