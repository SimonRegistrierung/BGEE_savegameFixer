﻿using System;

namespace BGEE_revisions
{
    internal class CreItemSlots
    {
        internal static int size = 80; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal int arrayOffset;

        internal short helmet;
        internal short armor;
        internal short shield;
        internal short gloves;
        internal short leftRing;
        internal short rightRing;
        internal short amulet;
        internal short belt;
        internal short boots;
        internal short weapon1;
        internal short weapon2;
        internal short weapon3;
        internal short weapon4;
        internal short quiver1;
        internal short quiver2;
        internal short quiver3;
        internal short quiver4;
        internal short cloak;
        internal short quickItem1;
        internal short quickItem2;
        internal short quickItem3;
        internal short inventory1;
        internal short inventory2;
        internal short inventory3;
        internal short inventory4;
        internal short inventory5;
        internal short inventory6;
        internal short inventory7;
        internal short inventory8;
        internal short inventory9;
        internal short inventory10;
        internal short inventory11;
        internal short inventory12;
        internal short inventory13;
        internal short inventory14;
        internal short inventory15;
        internal short inventory16;
        internal short magicallyCreatedWeapon;
        internal short weaponSlotSelected;
        internal short weaponAbilitySelected;
        
        internal CreItemSlots(byte[] byteArray, int offset)
        {
            this.baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            helmet = ConvertToShortData();
            armor = ConvertToShortData();
            shield = ConvertToShortData();
            gloves = ConvertToShortData();
            leftRing = ConvertToShortData();
            rightRing = ConvertToShortData();
            amulet = ConvertToShortData();
            belt = ConvertToShortData();
            boots = ConvertToShortData();
            weapon1 = ConvertToShortData();
            weapon2 = ConvertToShortData();
            weapon3 = ConvertToShortData();
            weapon4 = ConvertToShortData();
            quiver1 = ConvertToShortData();
            quiver2 = ConvertToShortData();
            quiver3 = ConvertToShortData();
            quiver4 = ConvertToShortData();
            cloak = ConvertToShortData();
            quickItem1 = ConvertToShortData();
            quickItem2 = ConvertToShortData();
            quickItem3 = ConvertToShortData();
            inventory1 = ConvertToShortData();
            inventory2 = ConvertToShortData();
            inventory3 = ConvertToShortData();
            inventory4 = ConvertToShortData();
            inventory5 = ConvertToShortData();
            inventory6 = ConvertToShortData();
            inventory7 = ConvertToShortData();
            inventory8 = ConvertToShortData();
            inventory9 = ConvertToShortData();
            inventory10 = ConvertToShortData();
            inventory11 = ConvertToShortData();
            inventory12 = ConvertToShortData();
            inventory13 = ConvertToShortData();
            inventory14 = ConvertToShortData();
            inventory15 = ConvertToShortData();
            inventory16 = ConvertToShortData();
            magicallyCreatedWeapon = ConvertToShortData();
            weaponSlotSelected = ConvertToShortData();
            weaponAbilitySelected = ConvertToShortData();
            
            size = baseOffset - offset;

            this.byteArray = null; // clear the byteList;
        }
        
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        
        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(helmet);
            CopyBytesToArray(armor);
            CopyBytesToArray(shield);
            CopyBytesToArray(gloves);
            CopyBytesToArray(leftRing);
            CopyBytesToArray(rightRing);
            CopyBytesToArray(amulet);
            CopyBytesToArray(belt);
            CopyBytesToArray(boots);
            CopyBytesToArray(weapon1);
            CopyBytesToArray(weapon2);
            CopyBytesToArray(weapon3);
            CopyBytesToArray(weapon4);
            CopyBytesToArray(quiver1);
            CopyBytesToArray(quiver2);
            CopyBytesToArray(quiver3);
            CopyBytesToArray(quiver4);
            CopyBytesToArray(cloak);
            CopyBytesToArray(quickItem1);
            CopyBytesToArray(quickItem2);
            CopyBytesToArray(quickItem3);
            CopyBytesToArray(inventory1);
            CopyBytesToArray(inventory2);
            CopyBytesToArray(inventory3);
            CopyBytesToArray(inventory4);
            CopyBytesToArray(inventory5);
            CopyBytesToArray(inventory6);
            CopyBytesToArray(inventory7);
            CopyBytesToArray(inventory8);
            CopyBytesToArray(inventory9);
            CopyBytesToArray(inventory10);
            CopyBytesToArray(inventory11);
            CopyBytesToArray(inventory12);
            CopyBytesToArray(inventory13);
            CopyBytesToArray(inventory14);
            CopyBytesToArray(inventory15);
            CopyBytesToArray(inventory16);
            CopyBytesToArray(magicallyCreatedWeapon);
            CopyBytesToArray(weaponSlotSelected);
            CopyBytesToArray(weaponAbilitySelected);
            
            return byteArray;
        }
        
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void PrintValues()
        {
            Console.WriteLine(helmet);
            Console.WriteLine(armor);
            Console.WriteLine(shield);
            Console.WriteLine(gloves);
            Console.WriteLine(leftRing);
            Console.WriteLine(rightRing);
            Console.WriteLine(amulet);
            Console.WriteLine(belt);
            Console.WriteLine(boots);
            Console.WriteLine(weapon1);
            Console.WriteLine(weapon2);
            Console.WriteLine(weapon3);
            Console.WriteLine(weapon4);
            Console.WriteLine(quiver1);
            Console.WriteLine(quiver2);
            Console.WriteLine(quiver3);
            Console.WriteLine(quiver4);
            Console.WriteLine(cloak);
            Console.WriteLine(quickItem1);
            Console.WriteLine(quickItem2);
            Console.WriteLine(quickItem3);
            Console.WriteLine(inventory1);
            Console.WriteLine(inventory2);
            Console.WriteLine(inventory3);
            Console.WriteLine(inventory4);
            Console.WriteLine(inventory5);
            Console.WriteLine(inventory6);
            Console.WriteLine(inventory7);
            Console.WriteLine(inventory8);
            Console.WriteLine(inventory9);
            Console.WriteLine(inventory10);
            Console.WriteLine(inventory11);
            Console.WriteLine(inventory12);
            Console.WriteLine(inventory13);
            Console.WriteLine(inventory14);
            Console.WriteLine(inventory15);
            Console.WriteLine(inventory16);
            Console.WriteLine(magicallyCreatedWeapon);
            Console.WriteLine(weaponSlotSelected);
            Console.WriteLine(weaponAbilitySelected);
        }
    }
}