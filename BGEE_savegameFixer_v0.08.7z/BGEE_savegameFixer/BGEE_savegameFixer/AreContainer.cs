﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class AreContainer
    {
        internal static int size = 192; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal short xCoordinate;
        internal short yCoordinate;
        internal short type;
        internal short lockDifficulty;
        internal int flags;
        internal short trapDetectionDifficulty;
        internal short trapRemovalDiffuculty;
        internal short isTrapped;
        internal short trapDetected;
        internal short trapLaunchXCoordinate;
        internal short trapLaunchYCoordinate;
        internal short boundingBoxLeft;
        internal short boundingBoxTop;
        internal short boundingBoxRight;
        internal short boundingBoxBottom;
        internal int indexFirstItem;
        internal int itemCount;
        internal String trapScript;
        internal int indexFirstVertex;
        internal short countVertices;
        internal short triggerRange;
        internal byte[] owner;
        internal String keyItem;
        internal int breakDifficulty;
        internal int lockpickString;
        internal byte[] unused;
        

        internal AreContainer(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            name = ConvertToStringData(32);
            xCoordinate = ConvertToShortData();
            yCoordinate = ConvertToShortData();
            type = ConvertToShortData();
            lockDifficulty = ConvertToShortData();
            flags = ConvertToIntData();
            trapDetectionDifficulty = ConvertToShortData();
            trapRemovalDiffuculty = ConvertToShortData();
            isTrapped = ConvertToShortData();
            trapDetected = ConvertToShortData();
            trapLaunchXCoordinate = ConvertToShortData();
            trapLaunchYCoordinate = ConvertToShortData();
            boundingBoxLeft = ConvertToShortData();
            boundingBoxTop = ConvertToShortData();
            boundingBoxRight = ConvertToShortData();
            boundingBoxBottom = ConvertToShortData();
            indexFirstItem = ConvertToIntData();
            itemCount = ConvertToIntData();
            trapScript = ConvertToStringData(8);
            indexFirstVertex = ConvertToIntData();
            countVertices = ConvertToShortData();
            triggerRange = ConvertToShortData();
            owner = ConvertToUnknownData(32);
            keyItem = ConvertToStringData(8);
            breakDifficulty = ConvertToIntData();
            lockpickString = ConvertToIntData();
            unused = ConvertToUnknownData(56);

            size = baseOffset - offset;
            // Console.WriteLine(size);
            
            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(xCoordinate);
            CopyBytesToArray(yCoordinate);
            CopyBytesToArray(type);
            CopyBytesToArray(lockDifficulty);
            CopyBytesToArray(flags);
            CopyBytesToArray(trapDetectionDifficulty);
            CopyBytesToArray(trapRemovalDiffuculty);
            CopyBytesToArray(isTrapped);
            CopyBytesToArray(trapDetected);
            CopyBytesToArray(trapLaunchXCoordinate);
            CopyBytesToArray(trapLaunchYCoordinate);
            CopyBytesToArray(boundingBoxLeft);
            CopyBytesToArray(boundingBoxTop);
            CopyBytesToArray(boundingBoxRight);
            CopyBytesToArray(boundingBoxBottom);
            CopyBytesToArray(indexFirstItem);
            CopyBytesToArray(itemCount);
            CopyBytesToArray(trapScript);
            CopyBytesToArray(indexFirstVertex);
            CopyBytesToArray(countVertices);
            CopyBytesToArray(triggerRange);
            CopyBytesToArray(owner);
            CopyBytesToArray(keyItem);
            CopyBytesToArray(breakDifficulty);
            CopyBytesToArray(lockpickString);
            CopyBytesToArray(unused);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}