﻿using System;
using System.Collections;
using System.Text;
using BGEE_revisions;

namespace BGEE_savegameFixer
{
    internal class GamCreStruct
    {
        internal int size;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        
        internal CreHeader creHeader;
        internal ArrayList creKnownSpells;
        internal ArrayList creMemorizedSpellsInfos;
        internal ArrayList creMemorizedSpells;
        internal ArrayList creEffects;
        internal ArrayList creItems;
        internal CreItemSlots creItemSlots;
        
        internal static CreKnownSpell currentCreKnownSpell;
        internal static CreMemorizedSpellsInfo currentCreMemorizedSpellsInfo;
        internal static CreMemorizedSpell currentCreMemorizedSpell;
        internal static CreEffect currentCreEffect;
        internal static CreItem currentCreItem;

        internal GamCreStruct(byte[] creByteArray, int offset)
        {
            baseOffset = offset;
            byteArray = creByteArray; // set the byteList

            // create header
            creHeader = new CreHeader(creByteArray, baseOffset);
            
            // Console.WriteLine(creHeader.alignmentId);

            // create known spells
            baseOffset = offset + creHeader.knownSpellsOffset;
            creKnownSpells = new ArrayList();
            if (creHeader.knownSpellsCount > 0) // check if there is an extended Header
            {
                for (int i = 0; i < creHeader.knownSpellsCount; i++)
                {
                    currentCreKnownSpell = new CreKnownSpell(creByteArray, baseOffset);
                    creKnownSpells.Add(currentCreKnownSpell);
                    baseOffset += CreKnownSpell.size; // increase offset by the size of the extended header to set the offset at the beginning of the next extended header
                }
            }

            // create memorized spells infos
            baseOffset = offset + creHeader.spellsMemoInfoOffset;
            creMemorizedSpellsInfos = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.spellsMemoInfoCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.spellsMemoInfoCount; j++)
                {
                    currentCreMemorizedSpellsInfo = new CreMemorizedSpellsInfo(creByteArray, baseOffset);
                    creMemorizedSpellsInfos.Add(currentCreMemorizedSpellsInfo);
                    baseOffset += CreMemorizedSpellsInfo.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    // Console.WriteLine(creHeader.memoSpellsCount);
                }
            }
            
            // create memorized spells
            baseOffset = offset + creHeader.memoSpellsOffset;
            creMemorizedSpells = new ArrayList();
            foreach (CreMemorizedSpellsInfo creMemorizedSpellsInfo in creMemorizedSpellsInfos)
            {
                for (int i = 0; i < creMemorizedSpellsInfo.spellCount; i++)
                {
                    currentCreMemorizedSpell = new CreMemorizedSpell(creByteArray, baseOffset);
                    creMemorizedSpells.Add(currentCreMemorizedSpell);
                    baseOffset += CreMemorizedSpell.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                    // Console.WriteLine(creHeader.memoSpellsCount);
                }
            }

            // create effects
            baseOffset = offset + creHeader.effectsOffset;
            creEffects = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.effectsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.effectsCount; j++)
                {
                    currentCreEffect = new CreEffect(creByteArray, baseOffset);
                    creEffects.Add(currentCreEffect);
                    baseOffset += CreEffect.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }

            // create items
            baseOffset = offset + creHeader.itemsOffset;
            creItems = new ArrayList();
            // Console.WriteLine(itmHeader.descIcon);
            if (creHeader.itemsCount > 0) // if there are any extended headers (only then can there be feature blocks)
            {
                for (int j = 0; j < creHeader.itemsCount; j++)
                {
                    currentCreItem = new CreItem(creByteArray, baseOffset);
                    creItems.Add(currentCreItem);
                    baseOffset += CreItem.size; // increase offset by the size of the feature block to set the offset at the beginning of the next feature block
                }
            }
            
            // create itemslots
            baseOffset = offset + creHeader.itemSlotsOffset;
            creItemSlots = new CreItemSlots(creByteArray, baseOffset);
                
            size = 
                CreHeader.size +
                creKnownSpells.Count * CreKnownSpell.size +
                creMemorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size +
                creMemorizedSpells.Count * CreMemorizedSpell.size +
                creEffects.Count * CreEffect.size +
                creItems.Count * CreItem.size +
                CreItemSlots.size;
            
            // Console.WriteLine(size);

            byteArray = null; // clear the byteList;
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[
                CreHeader.size + 
                creKnownSpells.Count * CreKnownSpell.size + 
                creMemorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size + 
                creMemorizedSpells.Count * CreMemorizedSpell.size + 
                CreItemSlots.size + 
                creItems.Count * CreItem.size + 
                creEffects.Count * CreEffect.size
            ]; // rewrite the byteArray
            
            arrayOffset = CreHeader.size;

            creHeader.knownSpellsOffset = arrayOffset;
            creHeader.knownSpellsCount = creKnownSpells.Count;
            // Console.WriteLine(creHeader.knownSpellsOffset + " : " + creHeader.knownSpellsCount);
            foreach (CreKnownSpell creKnownSpell in creKnownSpells)
            {
                CopyBytesToArray(creKnownSpell);
                // Console.WriteLine(creKnownSpell.resource);
            }

            creHeader.spellsMemoInfoOffset = arrayOffset;
            creHeader.spellsMemoInfoCount = creMemorizedSpellsInfos.Count;
            // Console.WriteLine(creHeader.spellsMemoInfoOffset + " : " + creHeader.spellsMemoInfoCount);
            foreach (CreMemorizedSpellsInfo creMemorizedSpellsInfo in creMemorizedSpellsInfos)
            {
                CopyBytesToArray(creMemorizedSpellsInfo);
                // Console.WriteLine(creMemorizedSpellsInfo.spellLevel);
            }
            
            creHeader.memoSpellsOffset = arrayOffset;
            creHeader.memoSpellsCount = creMemorizedSpells.Count;
            foreach (CreMemorizedSpell creMemorizedSpell in creMemorizedSpells)
            {
                CopyBytesToArray(creMemorizedSpell);
            }
            
            creHeader.itemSlotsOffset = arrayOffset;
            CopyBytesToArray(creItemSlots);
            
            creHeader.itemsOffset = arrayOffset;
            creHeader.itemsCount = creItems.Count;
            foreach (CreItem creItem in creItems)
            {
                CopyBytesToArray(creItem);
            }
            
            creHeader.effectsOffset = arrayOffset;
            creHeader.effectsCount = creEffects.Count;
            foreach (CreEffect creEffect in creEffects)
            {
                CopyBytesToArray(creEffect);
            }

            // Console.WriteLine(arrayOffset);
            
            // add header with altered offsets and counts @ offset 0
            arrayOffset = 0;
            CopyBytesToArray(creHeader);
            
            // new size
            // Console.WriteLine(size);
            size = CreHeader.size +
                   creKnownSpells.Count * CreKnownSpell.size +
                   creMemorizedSpellsInfos.Count * CreMemorizedSpellsInfo.size +
                   creMemorizedSpells.Count * CreMemorizedSpell.size +
                   CreItemSlots.size +
                   creItems.Count * CreItem.size +
                   creEffects.Count * CreEffect.size; 
            // Console.WriteLine(size);

            return byteArray;
        }
        
        internal void CopyBytesToArray(CreHeader variable)
        {
            // Console.WriteLine(variable.GetByteData().Length);
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreHeader.size);
            arrayOffset += CreHeader.size;
        }
        internal void CopyBytesToArray(CreKnownSpell variable)
        {
            // Console.WriteLine(variable.GetByteData().Length);
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreKnownSpell.size);
            arrayOffset += CreKnownSpell.size;
        }
        internal void CopyBytesToArray(CreMemorizedSpellsInfo variable)
        {
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreMemorizedSpellsInfo.size);
            arrayOffset += CreMemorizedSpellsInfo.size;
        }
        internal void CopyBytesToArray(CreMemorizedSpell variable)
        {
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreMemorizedSpell.size);
            arrayOffset += CreMemorizedSpell.size;
        }
        internal void CopyBytesToArray(CreEffect variable)
        {
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreEffect.size);
            arrayOffset += CreEffect.size;
        }
        internal void CopyBytesToArray(CreItem variable)
        {
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreItem.size);
            arrayOffset += CreItem.size;
        }
        internal void CopyBytesToArray(CreItemSlots variable)
        {
            System.Buffer.BlockCopy(variable.GetByteData(), 0, byteArray, arrayOffset, CreItemSlots.size);
            arrayOffset += CreItemSlots.size;
        }
    }
}