﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    internal class AreHeader
    {
        internal static int size = 284; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String signature;
        internal String version;
        internal String wedResource;
        internal int lastSaved;
        internal int areaType;
        internal String areaNorth;
        internal int edgeFlagsNorth;
        internal String areaEast;
        internal int edgeFlagsEast;
        internal String areaSouth;
        internal int edgeFlagsSouth;
        internal String areaWest;
        internal int edgeFlagsWest;
        internal short location;
        internal short rainProbability;
        internal short snowProbability;
        internal short fogProbability;
        internal short lightingProbability;
        internal byte overlayTransparency;
        internal byte unknown1;
        internal int offsetActors;
        internal short numberOfActors;
        internal short numberOfTrigger;
        internal int offsetTriggers;
        internal int offsetSpawnPoints;
        internal int numberOfSpawnPoints;
        internal int offsetEntrances;
        internal int numberOfEntraces;
        internal int offsetContainers;
        internal short numberOfContainers;
        internal short numberOfItems;
        internal int offsetItems;
        internal int offsetVertices;
        internal short numberOfVertices;
        internal short numberOfAmbients;
        internal int offsetAmbients;
        internal int offsetVariables;
        internal short numberOfVariables;
        internal short numberOfObjectFlags;
        internal int offsetObjectFlags;
        internal String areaScript;
        internal int exploredBitmaskSize;
        internal int exploredBitmaskOffset;
        internal int numberOfDoors;
        internal int offsetDoors;
        internal int numberOfAnimations;
        internal int offsetAnimations;
        internal int numberOfTiledObjects;
        internal int offsetTiledObjects;
        internal int songsOffset;
        internal int restEncountersOffset;
        internal int automapNotesOffset;
        internal int numberOfAutomapNotes;
        internal int offsetProjectileTraps;
        internal int numberOfProjectileTraps;
        internal String restMovieDay;
        internal String restMovieNight;
        internal byte[] unknown2;

        internal AreHeader(byte[] byteArray)
        {
            baseOffset = 0; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            signature = ConvertToStringData(4);
            version = ConvertToStringData(4);
            wedResource = ConvertToStringData(8);
            lastSaved = ConvertToIntData();
            areaType = ConvertToIntData();
            areaNorth = ConvertToStringData(8);
            edgeFlagsNorth = ConvertToIntData();
            areaEast = ConvertToStringData(8);
            edgeFlagsEast = ConvertToIntData();
            areaSouth = ConvertToStringData(8);
            edgeFlagsSouth = ConvertToIntData();
            areaWest = ConvertToStringData(8);
            edgeFlagsWest = ConvertToIntData();
            location = ConvertToShortData();
            rainProbability = ConvertToShortData();
            snowProbability = ConvertToShortData();
            fogProbability = ConvertToShortData();
            lightingProbability = ConvertToShortData();
            overlayTransparency = ConvertToByteData();
            unknown1 = ConvertToByteData();
            offsetActors = ConvertToIntData();
            numberOfActors = ConvertToShortData();
            numberOfTrigger = ConvertToShortData();
            offsetTriggers = ConvertToIntData();
            offsetSpawnPoints = ConvertToIntData();
            numberOfSpawnPoints = ConvertToIntData();
            offsetEntrances = ConvertToIntData();
            numberOfEntraces = ConvertToIntData();
            offsetContainers = ConvertToIntData();
            numberOfContainers = ConvertToShortData();
            numberOfItems = ConvertToShortData();
            offsetItems = ConvertToIntData();
            offsetVertices = ConvertToIntData();
            numberOfVertices = ConvertToShortData();
            numberOfAmbients = ConvertToShortData();
            offsetAmbients = ConvertToIntData();
            offsetVariables = ConvertToIntData();
            numberOfVariables = ConvertToShortData();
            numberOfObjectFlags = ConvertToShortData();
            offsetObjectFlags = ConvertToIntData();
            areaScript = ConvertToStringData(8);
            exploredBitmaskSize = ConvertToIntData();
            exploredBitmaskOffset = ConvertToIntData();
            numberOfDoors = ConvertToIntData();
            offsetDoors = ConvertToIntData();
            numberOfAnimations = ConvertToIntData();
            offsetAnimations = ConvertToIntData();
            numberOfTiledObjects = ConvertToIntData();
            offsetTiledObjects = ConvertToIntData();
            songsOffset = ConvertToIntData();
            restEncountersOffset = ConvertToIntData();
            automapNotesOffset = ConvertToIntData();
            numberOfAutomapNotes = ConvertToIntData();
            offsetProjectileTraps = ConvertToIntData();
            numberOfProjectileTraps = ConvertToIntData();
            restMovieDay = ConvertToStringData(8);
            restMovieNight = ConvertToStringData(8);
            unknown2 = ConvertToUnknownData(56);

            size = baseOffset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(signature);
            CopyBytesToArray(version);
            CopyBytesToArray(wedResource);
            CopyBytesToArray(lastSaved);
            CopyBytesToArray(areaType);
            CopyBytesToArray(areaNorth);
            CopyBytesToArray(edgeFlagsNorth);
            CopyBytesToArray(areaEast);
            CopyBytesToArray(edgeFlagsEast);
            CopyBytesToArray(areaSouth);
            CopyBytesToArray(edgeFlagsSouth);
            CopyBytesToArray(areaWest);
            CopyBytesToArray(edgeFlagsWest);
            CopyBytesToArray(location);
            CopyBytesToArray(rainProbability);
            CopyBytesToArray(snowProbability);
            CopyBytesToArray(fogProbability);
            CopyBytesToArray(lightingProbability);
            CopyBytesToArray(overlayTransparency);
            CopyBytesToArray(unknown1);
            CopyBytesToArray(offsetActors);
            CopyBytesToArray(numberOfActors);
            CopyBytesToArray(numberOfTrigger);
            CopyBytesToArray(offsetTriggers);
            CopyBytesToArray(offsetSpawnPoints);
            CopyBytesToArray(numberOfSpawnPoints);
            CopyBytesToArray(offsetEntrances);
            CopyBytesToArray(numberOfEntraces);
            CopyBytesToArray(offsetContainers);
            CopyBytesToArray(numberOfContainers);
            CopyBytesToArray(numberOfItems);
            CopyBytesToArray(offsetItems);
            CopyBytesToArray(offsetVertices);
            CopyBytesToArray(numberOfVertices);
            CopyBytesToArray(numberOfAmbients);
            CopyBytesToArray(offsetAmbients);
            CopyBytesToArray(offsetVariables);
            CopyBytesToArray(numberOfVariables);
            CopyBytesToArray(numberOfObjectFlags);
            CopyBytesToArray(offsetObjectFlags);
            CopyBytesToArray(areaScript);
            CopyBytesToArray(exploredBitmaskSize);
            CopyBytesToArray(exploredBitmaskOffset);
            CopyBytesToArray(numberOfDoors);
            CopyBytesToArray(offsetDoors);
            CopyBytesToArray(numberOfAnimations);
            CopyBytesToArray(offsetAnimations);
            CopyBytesToArray(numberOfTiledObjects);
            CopyBytesToArray(offsetTiledObjects);
            CopyBytesToArray(songsOffset);
            CopyBytesToArray(restEncountersOffset);
            CopyBytesToArray(automapNotesOffset);
            CopyBytesToArray(numberOfAutomapNotes);
            CopyBytesToArray(offsetProjectileTraps);
            CopyBytesToArray(numberOfProjectileTraps);
            CopyBytesToArray(restMovieDay);
            CopyBytesToArray(restMovieNight);
            CopyBytesToArray(unknown2);

            return byteArray;
        }

        internal void PrintAll()
        {
            Console.WriteLine("signature " + signature);
            Console.WriteLine("version " + version);
            Console.WriteLine("wedResource " + wedResource);
            Console.WriteLine("lastSaved " + lastSaved);
            Console.WriteLine("areaType " + areaType);
            Console.WriteLine("areaNorth " + areaNorth);
            Console.WriteLine("edgeFlagsNorth " + edgeFlagsNorth);
            Console.WriteLine("areaEast " + areaEast);
            Console.WriteLine("edgeFlagsEast " + edgeFlagsEast);
            Console.WriteLine("areaSouth " + areaSouth);
            Console.WriteLine("edgeFlagsSouth " + edgeFlagsSouth);
            Console.WriteLine("areaWest " + areaWest);
            Console.WriteLine("edgeFlagsWest " + edgeFlagsWest);
            Console.WriteLine("location " + location);
            Console.WriteLine("rainProbability " + rainProbability);
            Console.WriteLine("snowProbability " + snowProbability);
            Console.WriteLine("fogProbability " + fogProbability);
            Console.WriteLine("lightingProbability " + lightingProbability);
            Console.WriteLine("overlayTransparency " + overlayTransparency);
            Console.WriteLine("unknown1 " + unknown1);
            Console.WriteLine("offsetActors " + offsetActors);
            Console.WriteLine("numberOfActors " + numberOfActors);
            Console.WriteLine("numberOfTrigger " + numberOfTrigger);
            Console.WriteLine("offsetTriggers " + offsetTriggers);
            Console.WriteLine("offsetSpawnPoints " + offsetSpawnPoints);
            Console.WriteLine("numberOfSpawnPoints " + numberOfSpawnPoints);
            Console.WriteLine("offsetEntrances " + offsetEntrances);
            Console.WriteLine("numberOfEntraces " + numberOfEntraces);
            Console.WriteLine("offsetContainers " + offsetContainers);
            Console.WriteLine("numberOfContainers " + numberOfContainers);
            Console.WriteLine("numberOfItems " + numberOfItems);
            Console.WriteLine("offsetItems " + offsetItems);
            Console.WriteLine("offsetVertices " + offsetVertices);
            Console.WriteLine("numberOfVertices " + numberOfVertices);
            Console.WriteLine("numberOfAmbients " + numberOfAmbients);
            Console.WriteLine("offsetAmbients " + offsetAmbients);
            Console.WriteLine("offsetVariables " + offsetVariables);
            Console.WriteLine("numberOfVariables " + numberOfVariables);
            Console.WriteLine("numberOfObjectFlags " + numberOfObjectFlags);
            Console.WriteLine("offsetObjectFlags " + offsetObjectFlags);
            Console.WriteLine("areaScript " + areaScript);
            Console.WriteLine("exploredBitmaskSize " + exploredBitmaskSize);
            Console.WriteLine("exploredBitmaskOffset " + exploredBitmaskOffset);
            Console.WriteLine("numberOfDoors " + numberOfDoors);
            Console.WriteLine("offsetDoors " + offsetDoors);
            Console.WriteLine("numberOfAnimations " + numberOfAnimations);
            Console.WriteLine("offsetAnimations " + offsetAnimations);
            Console.WriteLine("numberOfTiledObjects " + numberOfTiledObjects);
            Console.WriteLine("offsetTiledObjects " + offsetTiledObjects);
            Console.WriteLine("songsOffset " + songsOffset);
            Console.WriteLine("restEncountersOffset " + restEncountersOffset);
            Console.WriteLine("automapNotesOffset " + automapNotesOffset);
            Console.WriteLine("numberOfAutomapNotes " + numberOfAutomapNotes);
            Console.WriteLine("offsetProjectileTraps " + offsetProjectileTraps);
            Console.WriteLine("numberOfProjectileTraps " + numberOfProjectileTraps);
            Console.WriteLine("restMovieDay " + restMovieDay);
            Console.WriteLine("restMovieNight " + restMovieNight);
            Console.WriteLine("unknown2 " + unknown2);
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}