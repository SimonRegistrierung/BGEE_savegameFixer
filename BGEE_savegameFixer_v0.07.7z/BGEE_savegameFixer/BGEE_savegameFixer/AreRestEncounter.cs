﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class AreRestEncounter
    {
        internal static int size = 228; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal int interruptionText1;
        internal int interruptionText2;
        internal int interruptionText3;
        internal int interruptionText4;
        internal int interruptionText5;
        internal int interruptionText6;
        internal int interruptionText7;
        internal int interruptionText8;
        internal int interruptionText9;
        internal int interruptionText10;
        internal String creature1;
        internal String creature2;
        internal String creature3;
        internal String creature4;
        internal String creature5;
        internal String creature6;
        internal String creature7;
        internal String creature8;
        internal String creature9;
        internal String creature10;
        internal short creatureCount;
        internal short difficulty;
        internal int removalTime;
        internal short movementRestrictionDistance1;
        internal short movementRestrictionDistance2;
        internal short maximumNumberCreatures;
        internal short enabled;
        internal short probabilityDayPerHour;
        internal short probabilityNightPerHour;
        internal byte[] unused;

        internal AreRestEncounter(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            name = ConvertToStringData(32);
            interruptionText1 = ConvertToIntData();
            interruptionText2 = ConvertToIntData();
            interruptionText3 = ConvertToIntData();
            interruptionText4 = ConvertToIntData();
            interruptionText5 = ConvertToIntData();
            interruptionText6 = ConvertToIntData();
            interruptionText7 = ConvertToIntData();
            interruptionText8 = ConvertToIntData();
            interruptionText9 = ConvertToIntData();
            interruptionText10 = ConvertToIntData();
            creature1 = ConvertToStringData(8);
            creature2 = ConvertToStringData(8);
            creature3 = ConvertToStringData(8);
            creature4 = ConvertToStringData(8);
            creature5 = ConvertToStringData(8);
            creature6 = ConvertToStringData(8);
            creature7 = ConvertToStringData(8);
            creature8 = ConvertToStringData(8);
            creature9 = ConvertToStringData(8);
            creature10 = ConvertToStringData(8);
            creatureCount = ConvertToShortData();
            difficulty = ConvertToShortData();
            removalTime = ConvertToIntData();
            movementRestrictionDistance1 = ConvertToShortData();
            movementRestrictionDistance2 = ConvertToShortData();
            maximumNumberCreatures = ConvertToShortData();
            enabled = ConvertToShortData();
            probabilityDayPerHour = ConvertToShortData();
            probabilityNightPerHour = ConvertToShortData();
            unused = ConvertToUnknownData(56);
            
            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
                Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(interruptionText1);
            CopyBytesToArray(interruptionText2);
            CopyBytesToArray(interruptionText3);
            CopyBytesToArray(interruptionText4);
            CopyBytesToArray(interruptionText5);
            CopyBytesToArray(interruptionText6);
            CopyBytesToArray(interruptionText7);
            CopyBytesToArray(interruptionText8);
            CopyBytesToArray(interruptionText9);
            CopyBytesToArray(interruptionText10);
            CopyBytesToArray(creature1);
            CopyBytesToArray(creature2);
            CopyBytesToArray(creature3);
            CopyBytesToArray(creature4);
            CopyBytesToArray(creature5);
            CopyBytesToArray(creature6);
            CopyBytesToArray(creature7);
            CopyBytesToArray(creature8);
            CopyBytesToArray(creature9);
            CopyBytesToArray(creature10);
            CopyBytesToArray(creatureCount);
            CopyBytesToArray(difficulty);
            CopyBytesToArray(removalTime);
            CopyBytesToArray(movementRestrictionDistance1);
            CopyBytesToArray(movementRestrictionDistance2);
            CopyBytesToArray(maximumNumberCreatures);
            CopyBytesToArray(enabled);
            CopyBytesToArray(probabilityDayPerHour);
            CopyBytesToArray(probabilityNightPerHour);
            CopyBytesToArray(unused);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}