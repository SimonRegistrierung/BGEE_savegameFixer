﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    internal class GamNpc
    {
        internal static int size = 600;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;

        internal short charSelection;
        internal short partyOrder;
        internal int offsetToCreResourceData; // Offset (from start of file) to CRE resource data for this character
        internal int sizeOfCreResourceData;
        internal String charName;
        internal int charOrientation;
        internal String charCurrentArea;
        internal short charCoordinateX;
        internal short charCoordinateY;
        internal short viewingRectangleCoordinateX;
        internal short viewingRectangleCoordinateY;
        internal short modalAction;
        internal short happiness;
        internal int unused1;
        internal int unused2;
        internal int unused3;
        internal int unused4;
        internal int unused5;
        internal int unused6;
        internal int unused7;
        internal int unused8;
        internal int unused9;
        internal int unused10;
        internal int unused11;
        internal int unused12;
        internal int unused13;
        internal int unused14;
        internal int unused15;
        internal int unused16;
        internal int unused17;
        internal int unused18;
        internal int unused19;
        internal int unused20;
        internal int unused21;
        internal int unused22;
        internal int unused23;
        internal int unused24;
        internal short indexIntoSlotsQuickWeapon1;
        internal short indexIntoSlotsQuickWeapon2;
        internal short indexIntoSlotsQuickWeapon3;
        internal short indexIntoSlotsQuickWeapon4;
        internal short quickWeaponSlotAbility1;
        internal short quickWeaponSlotAbility2;
        internal short quickWeaponSlotAbility3;
        internal short quickWeaponSlotAbility4;
        internal String quickSpellResource1;
        internal String quickSpellResource2;
        internal String quickSpellResource3;
        internal short indexIntoSlotsQuickItem1;
        internal short indexIntoSlotsQuickItem2;
        internal short indexIntoSlotsQuickItem3;
        internal short quickItemSlotAbility1;
        internal short quickItemSlotAbility2;
        internal short quickItemSlotAbility3;
        internal byte[] name;
        internal int talkCount;
        internal int mostPowerfulVanquishedName;
        internal int mostPowerfulVanquishedXpReward;
        internal int timeInParty;
        internal int timeJoined;
        internal byte partyMember;
        internal short unused;
        internal byte firstLetterCreResRef;
        internal int killsXpChapter;
        internal int killsNumberChapter;
        internal int killsXpGame;
        internal int killsNumberGame;
        internal String favouriteSpells1;
        internal String favouriteSpells2;
        internal String favouriteSpells3;
        internal String favouriteSpells4;
        internal short favouriteSpellCount1;
        internal short favouriteSpellCount2;
        internal short favouriteSpellCount3;
        internal short favouriteSpellCount4;
        internal String favouriteWeapons1;
        internal String favouriteWeapons2;
        internal String favouriteWeapons3;
        internal String favouriteWeapons4;
        internal short favouriteWeaponTime1;
        internal short favouriteWeaponTime2;
        internal short favouriteWeaponTime3;
        internal short favouriteWeaponTime4;
        internal byte[] voiceSet;
        
        internal GamNpc(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            charSelection = ConvertToShortData();
            partyOrder = ConvertToShortData();
            offsetToCreResourceData = ConvertToIntData(); // Offset (from start of file) to CRE resource data for this character
            sizeOfCreResourceData = ConvertToIntData();
            charName = ConvertToStringData(8);
            charOrientation = ConvertToIntData();
            charCurrentArea = ConvertToStringData(8);
            charCoordinateX = ConvertToShortData();
            charCoordinateY = ConvertToShortData();
            viewingRectangleCoordinateX = ConvertToShortData();
            viewingRectangleCoordinateY = ConvertToShortData();
            modalAction = ConvertToShortData();
            happiness = ConvertToShortData();
            unused1 = ConvertToIntData();
            unused2 = ConvertToIntData();
            unused3 = ConvertToIntData();
            unused4 = ConvertToIntData();
            unused5 = ConvertToIntData();
            unused6 = ConvertToIntData();
            unused7 = ConvertToIntData();
            unused8 = ConvertToIntData();
            unused9 = ConvertToIntData();
            unused10 = ConvertToIntData();
            unused11 = ConvertToIntData();
            unused12 = ConvertToIntData();
            unused13 = ConvertToIntData();
            unused14 = ConvertToIntData();
            unused15 = ConvertToIntData();
            unused16 = ConvertToIntData();
            unused17 = ConvertToIntData();
            unused18 = ConvertToIntData();
            unused19 = ConvertToIntData();
            unused20 = ConvertToIntData();
            unused21 = ConvertToIntData();
            unused22 = ConvertToIntData();
            unused23 = ConvertToIntData();
            unused24 = ConvertToIntData();
            indexIntoSlotsQuickWeapon1 = ConvertToShortData();
            indexIntoSlotsQuickWeapon2 = ConvertToShortData();
            indexIntoSlotsQuickWeapon3 = ConvertToShortData();
            indexIntoSlotsQuickWeapon4 = ConvertToShortData();
            quickWeaponSlotAbility1 = ConvertToShortData();
            quickWeaponSlotAbility2 = ConvertToShortData();
            quickWeaponSlotAbility3 = ConvertToShortData();
            quickWeaponSlotAbility4 = ConvertToShortData();
            quickSpellResource1 = ConvertToStringData(8);
            quickSpellResource2 = ConvertToStringData(8);
            quickSpellResource3 = ConvertToStringData(8);
            indexIntoSlotsQuickItem1 = ConvertToShortData();
            indexIntoSlotsQuickItem2 = ConvertToShortData();
            indexIntoSlotsQuickItem3 = ConvertToShortData();
            quickItemSlotAbility1 = ConvertToShortData();
            quickItemSlotAbility2 = ConvertToShortData();
            quickItemSlotAbility3 = ConvertToShortData();
            name = ConvertToUnknownData(32);
            talkCount = ConvertToIntData();
            mostPowerfulVanquishedName = ConvertToIntData();
            mostPowerfulVanquishedXpReward = ConvertToIntData();
            timeInParty = ConvertToIntData();
            timeJoined = ConvertToIntData();
            partyMember = ConvertToByteData();
            unused = ConvertToShortData();
            firstLetterCreResRef = ConvertToByteData();
            killsXpChapter = ConvertToIntData();
            killsNumberChapter = ConvertToIntData();
            killsXpGame = ConvertToIntData();
            killsNumberGame = ConvertToIntData();
            favouriteSpells1 = ConvertToStringData(8);
            favouriteSpells2 = ConvertToStringData(8);
            favouriteSpells3 = ConvertToStringData(8);
            favouriteSpells4 = ConvertToStringData(8);
            favouriteSpellCount1 = ConvertToShortData();
            favouriteSpellCount2 = ConvertToShortData();
            favouriteSpellCount3 = ConvertToShortData();
            favouriteSpellCount4 = ConvertToShortData();
            favouriteWeapons1 = ConvertToStringData(8);
            favouriteWeapons2 = ConvertToStringData(8);
            favouriteWeapons3 = ConvertToStringData(8);
            favouriteWeapons4 = ConvertToStringData(8);
            favouriteWeaponTime1 = ConvertToShortData();
            favouriteWeaponTime2 = ConvertToShortData();
            favouriteWeaponTime3 = ConvertToShortData();
            favouriteWeaponTime4 = ConvertToShortData();
            voiceSet = ConvertToUnknownData(8);
            
            size = baseOffset - offset;
            // Console.WriteLine(size);
            
            this.byteArray = null; // clear the byteList;
        }
    
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(charSelection);
            CopyBytesToArray(partyOrder);
            CopyBytesToArray(offsetToCreResourceData);
            CopyBytesToArray(sizeOfCreResourceData);
            CopyBytesToArray(charName);
            CopyBytesToArray(charOrientation);
            CopyBytesToArray(charCurrentArea);
            CopyBytesToArray(charCoordinateX);
            CopyBytesToArray(charCoordinateY);
            CopyBytesToArray(viewingRectangleCoordinateX);
            CopyBytesToArray(viewingRectangleCoordinateY);
            CopyBytesToArray(modalAction);
            CopyBytesToArray(happiness);
            CopyBytesToArray(unused1);
            CopyBytesToArray(unused2);
            CopyBytesToArray(unused3);
            CopyBytesToArray(unused4);
            CopyBytesToArray(unused5);
            CopyBytesToArray(unused6);
            CopyBytesToArray(unused7);
            CopyBytesToArray(unused8);
            CopyBytesToArray(unused9);
            CopyBytesToArray(unused10);
            CopyBytesToArray(unused11);
            CopyBytesToArray(unused12);
            CopyBytesToArray(unused13);
            CopyBytesToArray(unused14);
            CopyBytesToArray(unused15);
            CopyBytesToArray(unused16);
            CopyBytesToArray(unused17);
            CopyBytesToArray(unused18);
            CopyBytesToArray(unused19);
            CopyBytesToArray(unused20);
            CopyBytesToArray(unused21);
            CopyBytesToArray(unused22);
            CopyBytesToArray(unused23);
            CopyBytesToArray(unused24);
            CopyBytesToArray(indexIntoSlotsQuickWeapon1);
            CopyBytesToArray(indexIntoSlotsQuickWeapon2);
            CopyBytesToArray(indexIntoSlotsQuickWeapon3);
            CopyBytesToArray(indexIntoSlotsQuickWeapon4);
            CopyBytesToArray(quickWeaponSlotAbility1);
            CopyBytesToArray(quickWeaponSlotAbility2);
            CopyBytesToArray(quickWeaponSlotAbility3);
            CopyBytesToArray(quickWeaponSlotAbility4);
            CopyBytesToArray(quickSpellResource1);
            CopyBytesToArray(quickSpellResource2);
            CopyBytesToArray(quickSpellResource3);
            CopyBytesToArray(indexIntoSlotsQuickItem1);
            CopyBytesToArray(indexIntoSlotsQuickItem2);
            CopyBytesToArray(indexIntoSlotsQuickItem3);
            CopyBytesToArray(quickItemSlotAbility1);
            CopyBytesToArray(quickItemSlotAbility2);
            CopyBytesToArray(quickItemSlotAbility3);
            CopyBytesToArray(name);
            CopyBytesToArray(talkCount);
            CopyBytesToArray(mostPowerfulVanquishedName);
            CopyBytesToArray(mostPowerfulVanquishedXpReward);
            CopyBytesToArray(timeInParty);
            CopyBytesToArray(timeJoined);
            CopyBytesToArray(partyMember);
            CopyBytesToArray(unused);
            CopyBytesToArray(firstLetterCreResRef);
            CopyBytesToArray(killsXpChapter);
            CopyBytesToArray(killsNumberChapter);
            CopyBytesToArray(killsXpGame);
            CopyBytesToArray(killsNumberGame);
            CopyBytesToArray(favouriteSpells1);
            CopyBytesToArray(favouriteSpells2);
            CopyBytesToArray(favouriteSpells3);
            CopyBytesToArray(favouriteSpells4);
            CopyBytesToArray(favouriteSpellCount1);
            CopyBytesToArray(favouriteSpellCount2);
            CopyBytesToArray(favouriteSpellCount3);
            CopyBytesToArray(favouriteSpellCount4);
            CopyBytesToArray(favouriteWeapons1);
            CopyBytesToArray(favouriteWeapons2);
            CopyBytesToArray(favouriteWeapons3);
            CopyBytesToArray(favouriteWeapons4);
            CopyBytesToArray(favouriteWeaponTime1);
            CopyBytesToArray(favouriteWeaponTime2);
            CopyBytesToArray(favouriteWeaponTime3);
            CopyBytesToArray(favouriteWeaponTime4);
            CopyBytesToArray(voiceSet);

            return byteArray;
        }
        
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}