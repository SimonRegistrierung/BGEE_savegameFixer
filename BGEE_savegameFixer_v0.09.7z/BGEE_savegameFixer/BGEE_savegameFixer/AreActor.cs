﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    internal class AreActor
    {
        internal static int size = 272; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal short xCoordinate;
        internal short yCoordinate;
        internal short destXCoordinate;
        internal short destYCoordinate;
        internal int flags;
        internal short spawned;
        internal byte creFirstLetter;
        internal byte unused1;
        internal int animation;
        internal short orientation;
        internal short unused2;
        internal int removalTimer;
        internal short movementRestrictionDistance1;
        internal short movementRestrictionDistance2;
        internal int appearanceSchedule;
        internal int numTimesTalkedTo;
        internal String dialog;
        internal String scriptOverride;
        internal String scriptGeneral;
        internal String scriptClass;
        internal String scriptRace;
        internal String scriptDefault;
        internal String scriptSpecific;
        internal String creFile;
        internal int offsetCreStructure;
        internal int sizeCreStructure;
        internal string altActorName;
        internal byte[] unused3;

        internal AreActor(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList
            
            name = ConvertToStringData(32);
            xCoordinate = ConvertToShortData();
            yCoordinate = ConvertToShortData();
            destXCoordinate = ConvertToShortData();
            destYCoordinate = ConvertToShortData();
            flags = ConvertToIntData();
            spawned = ConvertToShortData();
            creFirstLetter = ConvertToByteData();
            unused1 = ConvertToByteData();
            animation = ConvertToIntData();
            orientation = ConvertToShortData();
            unused2 = ConvertToShortData();
            removalTimer = ConvertToIntData();
            movementRestrictionDistance1 = ConvertToShortData();
            movementRestrictionDistance2 = ConvertToShortData();
            appearanceSchedule = ConvertToIntData();
            numTimesTalkedTo = ConvertToIntData();
            dialog = ConvertToStringData(8);
            scriptOverride = ConvertToStringData(8);
            scriptGeneral = ConvertToStringData(8);
            scriptClass = ConvertToStringData(8);
            scriptRace = ConvertToStringData(8);
            scriptDefault = ConvertToStringData(8);
            scriptSpecific = ConvertToStringData(8);
            creFile = ConvertToStringData(8);
            offsetCreStructure = ConvertToIntData();
            sizeCreStructure = ConvertToIntData();
            altActorName = ConvertToStringData(32);
            unused3 = ConvertToUnknownData(96);

            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(xCoordinate);
            CopyBytesToArray(yCoordinate);
            CopyBytesToArray(destXCoordinate);
            CopyBytesToArray(destYCoordinate);
            CopyBytesToArray(flags);
            CopyBytesToArray(spawned);
            CopyBytesToArray(creFirstLetter);
            CopyBytesToArray(unused1);
            CopyBytesToArray(animation);
            CopyBytesToArray(orientation);
            CopyBytesToArray(unused2);
            CopyBytesToArray(removalTimer);
            CopyBytesToArray(movementRestrictionDistance1);
            CopyBytesToArray(movementRestrictionDistance2);
            CopyBytesToArray(appearanceSchedule);
            CopyBytesToArray(numTimesTalkedTo);
            CopyBytesToArray(dialog);
            CopyBytesToArray(scriptOverride);
            CopyBytesToArray(scriptGeneral);
            CopyBytesToArray(scriptClass);
            CopyBytesToArray(scriptRace);
            CopyBytesToArray(scriptDefault);
            CopyBytesToArray(scriptSpecific);
            CopyBytesToArray(creFile);
            CopyBytesToArray(offsetCreStructure);
            CopyBytesToArray(sizeCreStructure);
            CopyBytesToArray(altActorName);
            CopyBytesToArray(unused3);

            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}