﻿using System;
using System.Collections;
using System.IO;
using BGEE_revisions;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        internal static byte[] byteArray;

        internal static GamHeader gamHeader;
        internal static ArrayList gamNpcsParty;
        internal static ArrayList gamCreStructsParty;
        internal static ArrayList gamNpcsNonParty;
        internal static ArrayList gamCreStructsNonParty;
        internal static ArrayList gamVars;
        internal static ArrayList gamJournalEntries;
        internal static GamFamiliarInfo gamFamiliarInfo;
        internal static ArrayList gamStoredLocations;
        internal static ArrayList gamPocketPlaneInfos;

        internal static GamNpc currentGamNpc;
        internal static GamCreStruct currentCreStruct;
        internal static GamVar currentGamVar;
        internal static GamJournalEntry currentGamJournalEntry;
        internal static GamStoredLocationInfo currentGamStoredLocationInfo;
        internal static GamStoredLocationInfo currentGamPocketPlaneInfo;
        
        public static void Main(string[] args)
        {
            FileInfo[] savegames = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save");
            foreach (FileInfo savegame in savegames)
            {
                Console.WriteLine("WORKING ON " + savegame.FullName);
                CreateGamObjects(savegame.FullName);

                int viccyIndex = FindPartyCreIndex(@"*ICONI");
                try
                {
                    currentCreStruct = (GamCreStruct) gamCreStructsParty[viccyIndex];

                    for (int i = 0; i < currentCreStruct.creKnownSpells.Count; i++)
                    {
                        CreKnownSpell currentKnownSpell = (CreKnownSpell) currentCreStruct.creKnownSpells[i];
                        if (currentKnownSpell.resource.Contains("SPPR418"))
                        {
                            // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
                            currentCreStruct.creKnownSpells.RemoveAt(i);
                            currentCreStruct.creHeader.knownSpellsCount--;
                            currentCreStruct.creHeader.knownSpellsOffset -= 12;
                            // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
                        }
                    }

                    gamCreStructsParty[viccyIndex] = currentCreStruct;

                    FileOperations.WriteFile(
                        gamHeader,
                        gamNpcsParty,
                        gamCreStructsParty,
                        gamNpcsNonParty,
                        gamCreStructsNonParty,
                        gamVars,
                        gamJournalEntries,
                        gamFamiliarInfo,
                        gamStoredLocations,
                        gamPocketPlaneInfos,
                        savegame.FullName);
                }
                catch (Exception ignore)
                {
                    Console.WriteLine("Not found skipping...");
                }
            }
        }
    }
}