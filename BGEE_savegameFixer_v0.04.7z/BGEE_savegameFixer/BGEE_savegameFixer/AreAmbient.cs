﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class AreAmbient
    {
        internal static int size = 212; // size in bytes
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;
        //
        internal String name;
        internal short xCoordinate;
        internal short yCoordinate;
        internal short radius;
        internal short height;
        internal int pitchVariance;
        internal short volumeVariance;
        internal short volumePercentage;
        internal String resRefSound1;
        internal String resRefSound2;
        internal String resRefSound3;
        internal String resRefSound4;
        internal String resRefSound5;
        internal String resRefSound6;
        internal String resRefSound7;
        internal String resRefSound8;
        internal String resRefSound9;
        internal String resRefSound10;
        internal short soundCount;
        internal short unused1;
        internal int baseTimeBetweenSounds;
        internal int baseTimeDeviation;
        internal int appearanceSchedule;
        internal int flags;
        internal byte[] unused2;


        internal AreAmbient(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            name = ConvertToStringData(32);
            xCoordinate = ConvertToShortData();
            yCoordinate = ConvertToShortData();
            radius = ConvertToShortData();
            height = ConvertToShortData();
            pitchVariance = ConvertToIntData();
            volumeVariance = ConvertToShortData();
            volumePercentage = ConvertToShortData();
            resRefSound1 = ConvertToStringData(8);
            resRefSound2 = ConvertToStringData(8);
            resRefSound3 = ConvertToStringData(8);
            resRefSound4 = ConvertToStringData(8);
            resRefSound5 = ConvertToStringData(8);
            resRefSound6 = ConvertToStringData(8);
            resRefSound7 = ConvertToStringData(8);
            resRefSound8 = ConvertToStringData(8);
            resRefSound9 = ConvertToStringData(8);
            resRefSound10 = ConvertToStringData(8);
            soundCount = ConvertToShortData();
            unused1 = ConvertToShortData();
            baseTimeBetweenSounds = ConvertToIntData();
            baseTimeDeviation = ConvertToIntData();
            appearanceSchedule = ConvertToIntData();
            flags = ConvertToIntData();
            unused2 = ConvertToUnknownData(64);
            
            size = baseOffset - offset;
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(name);
            CopyBytesToArray(xCoordinate);
            CopyBytesToArray(yCoordinate);
            CopyBytesToArray(radius);
            CopyBytesToArray(height);
            CopyBytesToArray(pitchVariance);
            CopyBytesToArray(volumeVariance);
            CopyBytesToArray(volumePercentage);
            CopyBytesToArray(resRefSound1);
            CopyBytesToArray(resRefSound2);
            CopyBytesToArray(resRefSound3);
            CopyBytesToArray(resRefSound4);
            CopyBytesToArray(resRefSound5);
            CopyBytesToArray(resRefSound6);
            CopyBytesToArray(resRefSound7);
            CopyBytesToArray(resRefSound8);
            CopyBytesToArray(resRefSound9);
            CopyBytesToArray(resRefSound10);
            CopyBytesToArray(soundCount);
            CopyBytesToArray(unused1);
            CopyBytesToArray(baseTimeBetweenSounds);
            CopyBytesToArray(baseTimeDeviation);
            CopyBytesToArray(appearanceSchedule);
            CopyBytesToArray(flags);
            CopyBytesToArray(unused2);
            
            return byteArray;
        }

        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}