﻿using System;
using System.Collections;
using System.IO;
using BGEE_savegameFixer;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        internal static byte[] gamByteArray;
        internal static byte[] savByteArray;

        // GAME OBJECTS
        
        internal static GamHeader gamHeader;
        internal static ArrayList gamNpcsParty;
        internal static ArrayList gamCreStructsParty;
        internal static ArrayList gamNpcsNonParty;
        internal static ArrayList gamCreStructsNonParty;
        internal static ArrayList gamVars;
        internal static ArrayList gamJournalEntries;
        internal static GamFamiliarInfo gamFamiliarInfo;
        internal static ArrayList gamStoredLocations;
        internal static ArrayList gamPocketPlaneInfos;

        internal static GamNpc currentGamNpc;
        internal static GamCreStruct currentGamCreStruct;
        internal static GamVar currentGamVar;
        internal static GamJournalEntry currentGamJournalEntry;
        internal static GamStoredLocationInfo currentGamStoredLocationInfo;
        internal static GamStoredLocationInfo currentGamPocketPlaneInfo;

        // SAVE OBJECTS
        
        internal static SavHeader savHeader;
        internal static ArrayList savFiles;
        
        internal static SavFile currentSavFile;

        public static void Main(string[] args)
        {
            FileInfo[] gamFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "gam");
            FileInfo[] savFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "sav");
            
            // /////////// //
            // GAM EDITING //
            // /////////// //
            
            // foreach (FileInfo gamFile in gamFiles)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //
            //     int viccyIndex = FindPartyCreIndex(@"*ICONI");
            //     try
            //     {
            //         currentCreStruct = (GamCreStruct) gamCreStructsParty[viccyIndex];
            //
            //         for (int i = 0; i < currentCreStruct.creKnownSpells.Count; i++)
            //         {
            //             CreKnownSpell currentKnownSpell = (CreKnownSpell) currentCreStruct.creKnownSpells[i];
            //             if (currentKnownSpell.resource.Contains("SPPR418"))
            //             {
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //                 currentCreStruct.creKnownSpells.RemoveAt(i);
            //                 currentCreStruct.creHeader.knownSpellsCount--;
            //                 currentCreStruct.creHeader.knownSpellsOffset -= 12;
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //             }
            //         }
            //
            //         gamCreStructsParty[viccyIndex] = currentCreStruct;
            //
            //         FileOperations.WriteFile(
            //             gamHeader,
            //             gamNpcsParty,
            //             gamCreStructsParty,
            //             gamNpcsNonParty,
            //             gamCreStructsNonParty,
            //             gamVars,
            //             gamJournalEntries,
            //             gamFamiliarInfo,
            //             gamStoredLocations,
            //             gamPocketPlaneInfos,
            //             gamFile.FullName);
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            // /////////// //
            // SAV EDITING //
            // /////////// //
            
            foreach (FileInfo savFileInfo in savFileInfos)
            {
                CreateSavObjects(savFileInfo.FullName);
            
                foreach (SavFile savFile in savFiles)
                {
                    savFile.Decompress();
                    if (savFile.filename.Contains("KEYR") && savFile.filename.Contains(".sto"))
                    {
                        savFile.stoHeader.capacity = 50;
                    }
                    savFile.Compress();
                }
                FileOperations.WriteFile(savHeader, savFiles, savFileInfo.FullName);
            }
        }
    }
}