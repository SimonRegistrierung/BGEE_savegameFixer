﻿using System;
using System.Collections;
using System.IO;
using BGEE_revisions;

namespace BGEE_savegameFixer
{
    internal class FileOperations
    {
        internal static Boolean CheckFilePath(String path)
        {
            if (!File.Exists(path))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        internal static void CheckBasePath(String path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        internal static byte[] ReadFile(String filePath)
        {
            if (File.Exists(filePath))
            {
                // NEW METHOD: ALL AT ONCE
                return File.ReadAllBytes(filePath);
            }
            else
            {
                // Console.WriteLine("File doesn't exist!");
                return null;
            }
        }
        
        internal static String ReadFileAsString(String filePath)
        {
            if (File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            else
            {
                throw new FileNotFoundException();
            }
        }

        internal static void WriteFile(String filePath, byte[] byteFile)
        {
            File.WriteAllBytes(filePath, byteFile);
        }
        
        internal static void WriteFile(String sourcePath, String destPath)
        {
            File.Copy(sourcePath, destPath, true);
        }
        
        internal static void WriteFileAsString(String fileContent, String filePath)
        {
            File.WriteAllText(filePath, fileContent);
        }

        internal static int[] GetStructOffsets(ArrayList list, int begin)
        {
            int[] offsets = new int[list.Count];
            int index = 0;
            int offset = begin;
            foreach (GamCreStruct creStruct in list)
            {
                offsets[index] = offset;
                offset += creStruct.size;
                index++;
            }

            return offsets;
        }

        internal static void WriteFile(GamHeader header, ArrayList partyNpcs, ArrayList partyCreStructs, ArrayList nonPartyNpcs, ArrayList nonPartyCreStructs, ArrayList vars, ArrayList journalEntries, GamFamiliarInfo familiarInfo, ArrayList storedLocations, ArrayList pocketPlaneInfos, String filePath)
        {
            int partyCreStructsSize = 0;
            foreach (GamCreStruct partyCreStruct in partyCreStructs)
            {
                partyCreStructsSize += partyCreStruct.size;
            }
            int nonPartyCreStructsSize = 0;
            foreach (GamCreStruct nonPartyCreStruct in nonPartyCreStructs)
            {
                nonPartyCreStructsSize += nonPartyCreStruct.size;
            }
            
            
            byte[] byteFile = new byte[
                GamHeader.size + 
                partyNpcs.Count * GamNpc.size + 
                partyCreStructsSize + 
                nonPartyNpcs.Count * GamNpc.size +
                nonPartyCreStructsSize + 
                vars.Count * GamVar.size + 
                journalEntries.Count * GamJournalEntry.size +
                GamFamiliarInfo.size +
                storedLocations.Count * GamStoredLocationInfo.size + 
                pocketPlaneInfos.Count * GamStoredLocationInfo.size 
            ];
            int offset = 0;
            byte[] bytes = header.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += GamHeader.size;

            int[] structOffsets = GetStructOffsets(partyCreStructs, offset + partyNpcs.Count * GamNpc.size);
            int index = 0;
            header.offsetNpcStructsParty = offset;
            header.countNpcStructsParty = partyNpcs.Count;
            if (header.countNpcStructsParty > 0)
            {
                foreach (GamNpc partyNpc in partyNpcs)
                {
                    partyNpc.offsetToCreResourceData = structOffsets[index];
                    // Console.WriteLine(partyNpc.offsetToCreResourceData);
                    bytes = partyNpc.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += GamNpc.size;
                    index++;
                }
                foreach (GamCreStruct partyCreStruct in partyCreStructs)
                {
                    bytes = partyCreStruct.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += partyCreStruct.size;
                }
            }
            
            structOffsets = GetStructOffsets(partyCreStructs, offset + nonPartyNpcs.Count * GamNpc.size);
            index = 0;
            header.offsetNpcStructsNonParty = offset;
            header.countNpcStructsNonParty = nonPartyNpcs.Count;
            if (header.countNpcStructsNonParty > 0)
            {
                foreach (GamNpc nonPartyNpc in nonPartyNpcs)
                {
                    // nonPartyNpc.offsetToCreResourceData = structOffsets[index];
                    bytes = nonPartyNpc.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += GamNpc.size;
                    index++;
                }
                foreach (GamCreStruct nonPartyCreStruct in nonPartyCreStructs)
                {
                    bytes = nonPartyCreStruct.GetByteData();
                    System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                    offset += nonPartyCreStruct.size;
                }
            }

            header.offsetGlobalNamespaceVars = offset;
            header.countGlobalNamespaceVars = vars.Count;
            foreach (GamVar var in vars)
            {
                bytes = var.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamVar.size;
            }
            
            header.offsetJournalEntries = offset;
            header.countJournalEntries = journalEntries.Count;
            foreach (GamJournalEntry journalEntry in journalEntries)
            {
                bytes = journalEntry.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamJournalEntry.size;
            }
            
            header.offsetFamiliarInfo = offset;
            bytes = familiarInfo.GetByteData();
            System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
            offset += GamFamiliarInfo.size;
            
            header.offsetStoredLocations = offset;
            header.countStoredLocations = storedLocations.Count;
            foreach (GamStoredLocationInfo storedLocation in storedLocations)
            {
                bytes = storedLocation.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamStoredLocationInfo.size;
            }
            
            header.offsetStoredLocations = offset;
            header.countStoredLocations = pocketPlaneInfos.Count;
            foreach (GamStoredLocationInfo pocketPlaneInfo in pocketPlaneInfos)
            {
                bytes = pocketPlaneInfo.GetByteData();
                System.Buffer.BlockCopy(bytes, 0, byteFile, offset, bytes.Length);
                offset += GamStoredLocationInfo.size;
            }

            if (offset != byteFile.Length) // if the offset is of different length than the current byteFile, rerun the routine
            {
                Console.WriteLine(offset + "  " + byteFile.Length);
                // Console.WriteLine("------------------------------");
                WriteFile(header, partyNpcs, partyCreStructs, nonPartyNpcs, nonPartyCreStructs, vars, journalEntries, familiarInfo, storedLocations, pocketPlaneInfos, filePath);
            }
            else
            {
                // Console.WriteLine("------------------------------");
                // Console.WriteLine(offset + "  " + byteFile.Length);
                File.WriteAllBytes(filePath, byteFile);
            }
        }
    }
}