﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class GamJournalEntry
    {
        internal static int size = 12;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;

        internal int journalText;
        internal int timeInSecs;
        internal byte currChapterNum;
        internal byte readByCharX;
        internal byte journalSection;
        internal byte locationflag;
        
        
        
        internal GamJournalEntry(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            journalText = ConvertToIntData();
            timeInSecs = ConvertToIntData();
            currChapterNum = ConvertToByteData();
            readByCharX = ConvertToByteData();
            journalSection = ConvertToByteData();
            locationflag = ConvertToByteData();

            size = baseOffset - offset;
            
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(journalText);
            CopyBytesToArray(timeInSecs);
            CopyBytesToArray(currChapterNum);
            CopyBytesToArray(readByCharX);
            CopyBytesToArray(journalSection);
            CopyBytesToArray(locationflag);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}