﻿using System;
using System.Text;

namespace BGEE_savegameFixer
{
    public class GamFamiliarInfo
    {
        internal static int size = 592;
        internal byte[] byteArray;
        internal int baseOffset;
        internal StringBuilder stringBuilder;
        internal int arrayOffset;

        internal String lawfulGood;
        internal String lawfulNeutral;
        internal String lawfulEvil;
        internal String neutralGood;
        internal String neutralneutral;
        internal String neutralEvil;
        internal String chaoticGood;
        internal String chaoticNeutral;
        internal String chaoticEvil;
        internal int offsetFamiliarResources;
        internal int lgFamiliarCountLevel1;
        internal int lgFamiliarCountLevel2;
        internal int lgFamiliarCountLevel3;
        internal int lgFamiliarCountLevel4;
        internal int lgFamiliarCountLevel5;
        internal int lgFamiliarCountLevel6;
        internal int lgFamiliarCountLevel7;
        internal int lgFamiliarCountLevel8;
        internal int lgFamiliarCountLevel9;
        internal int lnFamiliarCountLevel1;
        internal int lnFamiliarCountLevel2;
        internal int lnFamiliarCountLevel3;
        internal int lnFamiliarCountLevel4;
        internal int lnFamiliarCountLevel5;
        internal int lnFamiliarCountLevel6;
        internal int lnFamiliarCountLevel7;
        internal int lnFamiliarCountLevel8;
        internal int lnFamiliarCountLevel9;
        internal int leFamiliarCountLevel1;
        internal int leFamiliarCountLevel2;
        internal int leFamiliarCountLevel3;
        internal int leFamiliarCountLevel4;
        internal int leFamiliarCountLevel5;
        internal int leFamiliarCountLevel6;
        internal int leFamiliarCountLevel7;
        internal int leFamiliarCountLevel8;
        internal int leFamiliarCountLevel9;
        internal int ngFamiliarCountLevel1;
        internal int ngFamiliarCountLevel2;
        internal int ngFamiliarCountLevel3;
        internal int ngFamiliarCountLevel4;
        internal int ngFamiliarCountLevel5;
        internal int ngFamiliarCountLevel6;
        internal int ngFamiliarCountLevel7;
        internal int ngFamiliarCountLevel8;
        internal int ngFamiliarCountLevel9;
        internal int nnFamiliarCountLevel1;
        internal int nnFamiliarCountLevel2;
        internal int nnFamiliarCountLevel3;
        internal int nnFamiliarCountLevel4;
        internal int nnFamiliarCountLevel5;
        internal int nnFamiliarCountLevel6;
        internal int nnFamiliarCountLevel7;
        internal int nnFamiliarCountLevel8;
        internal int nnFamiliarCountLevel9;
        internal int neFamiliarCountLevel1;
        internal int neFamiliarCountLevel2;
        internal int neFamiliarCountLevel3;
        internal int neFamiliarCountLevel4;
        internal int neFamiliarCountLevel5;
        internal int neFamiliarCountLevel6;
        internal int neFamiliarCountLevel7;
        internal int neFamiliarCountLevel8;
        internal int neFamiliarCountLevel9;
        internal int cgFamiliarCountLevel1;
        internal int cgFamiliarCountLevel2;
        internal int cgFamiliarCountLevel3;
        internal int cgFamiliarCountLevel4;
        internal int cgFamiliarCountLevel5;
        internal int cgFamiliarCountLevel6;
        internal int cgFamiliarCountLevel7;
        internal int cgFamiliarCountLevel8;
        internal int cgFamiliarCountLevel9;
        internal int cnFamiliarCountLevel1;
        internal int cnFamiliarCountLevel2;
        internal int cnFamiliarCountLevel3;
        internal int cnFamiliarCountLevel4;
        internal int cnFamiliarCountLevel5;
        internal int cnFamiliarCountLevel6;
        internal int cnFamiliarCountLevel7;
        internal int cnFamiliarCountLevel8;
        internal int cnFamiliarCountLevel9;
        internal int ceFamiliarCountLevel1;
        internal int ceFamiliarCountLevel2;
        internal int ceFamiliarCountLevel3;
        internal int ceFamiliarCountLevel4;
        internal int ceFamiliarCountLevel5;
        internal int ceFamiliarCountLevel6;
        internal int ceFamiliarCountLevel7;
        internal int ceFamiliarCountLevel8;
        internal int ceFamiliarCountLevel9;

        
        internal GamFamiliarInfo(byte[] byteArray, int offset)
        {
            baseOffset = offset; // where to begin looking for data
            this.byteArray = byteArray; // set the byteList

            lawfulGood = ConvertToStringData(8);
            lawfulNeutral = ConvertToStringData(8);
            lawfulEvil = ConvertToStringData(8);
            neutralGood = ConvertToStringData(8);
            neutralneutral = ConvertToStringData(8);
            neutralEvil = ConvertToStringData(8);
            chaoticGood = ConvertToStringData(8);
            chaoticNeutral = ConvertToStringData(8);
            chaoticEvil = ConvertToStringData(8);
            offsetFamiliarResources = ConvertToIntData();
            lgFamiliarCountLevel1 = ConvertToIntData();
            lgFamiliarCountLevel2 = ConvertToIntData();
            lgFamiliarCountLevel3 = ConvertToIntData();
            lgFamiliarCountLevel4 = ConvertToIntData();
            lgFamiliarCountLevel5 = ConvertToIntData();
            lgFamiliarCountLevel6 = ConvertToIntData();
            lgFamiliarCountLevel7 = ConvertToIntData();
            lgFamiliarCountLevel8 = ConvertToIntData();
            lgFamiliarCountLevel9 = ConvertToIntData();
            lnFamiliarCountLevel1 = ConvertToIntData();
            lnFamiliarCountLevel2 = ConvertToIntData();
            lnFamiliarCountLevel3 = ConvertToIntData();
            lnFamiliarCountLevel4 = ConvertToIntData();
            lnFamiliarCountLevel5 = ConvertToIntData();
            lnFamiliarCountLevel6 = ConvertToIntData();
            lnFamiliarCountLevel7 = ConvertToIntData();
            lnFamiliarCountLevel8 = ConvertToIntData();
            lnFamiliarCountLevel9 = ConvertToIntData();
            leFamiliarCountLevel1 = ConvertToIntData();
            leFamiliarCountLevel2 = ConvertToIntData();
            leFamiliarCountLevel3 = ConvertToIntData();
            leFamiliarCountLevel4 = ConvertToIntData();
            leFamiliarCountLevel5 = ConvertToIntData();
            leFamiliarCountLevel6 = ConvertToIntData();
            leFamiliarCountLevel7 = ConvertToIntData();
            leFamiliarCountLevel8 = ConvertToIntData();
            leFamiliarCountLevel9 = ConvertToIntData();
            ngFamiliarCountLevel1 = ConvertToIntData();
            ngFamiliarCountLevel2 = ConvertToIntData();
            ngFamiliarCountLevel3 = ConvertToIntData();
            ngFamiliarCountLevel4 = ConvertToIntData();
            ngFamiliarCountLevel5 = ConvertToIntData();
            ngFamiliarCountLevel6 = ConvertToIntData();
            ngFamiliarCountLevel7 = ConvertToIntData();
            ngFamiliarCountLevel8 = ConvertToIntData();
            ngFamiliarCountLevel9 = ConvertToIntData();
            nnFamiliarCountLevel1 = ConvertToIntData();
            nnFamiliarCountLevel2 = ConvertToIntData();
            nnFamiliarCountLevel3 = ConvertToIntData();
            nnFamiliarCountLevel4 = ConvertToIntData();
            nnFamiliarCountLevel5 = ConvertToIntData();
            nnFamiliarCountLevel6 = ConvertToIntData();
            nnFamiliarCountLevel7 = ConvertToIntData();
            nnFamiliarCountLevel8 = ConvertToIntData();
            nnFamiliarCountLevel9 = ConvertToIntData();
            neFamiliarCountLevel1 = ConvertToIntData();
            neFamiliarCountLevel2 = ConvertToIntData();
            neFamiliarCountLevel3 = ConvertToIntData();
            neFamiliarCountLevel4 = ConvertToIntData();
            neFamiliarCountLevel5 = ConvertToIntData();
            neFamiliarCountLevel6 = ConvertToIntData();
            neFamiliarCountLevel7 = ConvertToIntData();
            neFamiliarCountLevel8 = ConvertToIntData();
            neFamiliarCountLevel9 = ConvertToIntData();
            cgFamiliarCountLevel1 = ConvertToIntData();
            cgFamiliarCountLevel2 = ConvertToIntData();
            cgFamiliarCountLevel3 = ConvertToIntData();
            cgFamiliarCountLevel4 = ConvertToIntData();
            cgFamiliarCountLevel5 = ConvertToIntData();
            cgFamiliarCountLevel6 = ConvertToIntData();
            cgFamiliarCountLevel7 = ConvertToIntData();
            cgFamiliarCountLevel8 = ConvertToIntData();
            cgFamiliarCountLevel9 = ConvertToIntData();
            cnFamiliarCountLevel1 = ConvertToIntData();
            cnFamiliarCountLevel2 = ConvertToIntData();
            cnFamiliarCountLevel3 = ConvertToIntData();
            cnFamiliarCountLevel4 = ConvertToIntData();
            cnFamiliarCountLevel5 = ConvertToIntData();
            cnFamiliarCountLevel6 = ConvertToIntData();
            cnFamiliarCountLevel7 = ConvertToIntData();
            cnFamiliarCountLevel8 = ConvertToIntData();
            cnFamiliarCountLevel9 = ConvertToIntData();
            ceFamiliarCountLevel1 = ConvertToIntData();
            ceFamiliarCountLevel2 = ConvertToIntData();
            ceFamiliarCountLevel3 = ConvertToIntData();
            ceFamiliarCountLevel4 = ConvertToIntData();
            ceFamiliarCountLevel5 = ConvertToIntData();
            ceFamiliarCountLevel6 = ConvertToIntData();
            ceFamiliarCountLevel7 = ConvertToIntData();
            ceFamiliarCountLevel8 = ConvertToIntData();
            ceFamiliarCountLevel9 = ConvertToIntData();

            size = baseOffset - offset;
            
            // Console.WriteLine(size);

            this.byteArray = null; // clear the byteList;
        }

        internal double ConvertToDoubleData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 8; // increase baseOffset 4 bytes
            return BitConverter.ToDouble(byteArray, currentOffset);
        }
        internal byte[] ConvertToUnknownData(int dataSize)
        {
            byte[] byteFragment = new byte[dataSize];
            Buffer.BlockCopy(byteArray, baseOffset, byteFragment, 0, dataSize);
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return byteFragment;
        }
        internal String ConvertToStringData(int dataSize)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(Encoding.ASCII.GetString(byteArray, baseOffset, dataSize));
            baseOffset += dataSize; // increase baseOffset by dataSize (variable)
            return stringBuilder.ToString();
        }
        internal int ConvertToIntData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 4; // increase baseOffset 4 bytes
            return BitConverter.ToInt32(byteArray, currentOffset);
        }
        internal short ConvertToShortData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 2; // increase baseOffset 2 bytes
            return BitConverter.ToInt16(byteArray, currentOffset);
        }
        internal byte ConvertToByteData()
        {
            int currentOffset = baseOffset; 
            baseOffset += 1; // increase baseOffset 1 byte
            return byteArray[currentOffset];
        }

        internal byte[] GetByteData()
        {
            byteArray = new byte[size]; // rewrite the byteArray
            arrayOffset = 0;

            CopyBytesToArray(lawfulGood);
            CopyBytesToArray(lawfulNeutral);
            CopyBytesToArray(lawfulEvil);
            CopyBytesToArray(neutralGood);
            CopyBytesToArray(neutralneutral);
            CopyBytesToArray(neutralEvil);
            CopyBytesToArray(chaoticGood);
            CopyBytesToArray(chaoticNeutral);
            CopyBytesToArray(chaoticEvil);
            CopyBytesToArray(offsetFamiliarResources);
            CopyBytesToArray(lgFamiliarCountLevel1);
            CopyBytesToArray(lgFamiliarCountLevel2);
            CopyBytesToArray(lgFamiliarCountLevel3);
            CopyBytesToArray(lgFamiliarCountLevel4);
            CopyBytesToArray(lgFamiliarCountLevel5);
            CopyBytesToArray(lgFamiliarCountLevel6);
            CopyBytesToArray(lgFamiliarCountLevel7);
            CopyBytesToArray(lgFamiliarCountLevel8);
            CopyBytesToArray(lgFamiliarCountLevel9);
            CopyBytesToArray(lnFamiliarCountLevel1);
            CopyBytesToArray(lnFamiliarCountLevel2);
            CopyBytesToArray(lnFamiliarCountLevel3);
            CopyBytesToArray(lnFamiliarCountLevel4);
            CopyBytesToArray(lnFamiliarCountLevel5);
            CopyBytesToArray(lnFamiliarCountLevel6);
            CopyBytesToArray(lnFamiliarCountLevel7);
            CopyBytesToArray(lnFamiliarCountLevel8);
            CopyBytesToArray(lnFamiliarCountLevel9);
            CopyBytesToArray(leFamiliarCountLevel1);
            CopyBytesToArray(leFamiliarCountLevel2);
            CopyBytesToArray(leFamiliarCountLevel3);
            CopyBytesToArray(leFamiliarCountLevel4);
            CopyBytesToArray(leFamiliarCountLevel5);
            CopyBytesToArray(leFamiliarCountLevel6);
            CopyBytesToArray(leFamiliarCountLevel7);
            CopyBytesToArray(leFamiliarCountLevel8);
            CopyBytesToArray(leFamiliarCountLevel9);
            CopyBytesToArray(ngFamiliarCountLevel1);
            CopyBytesToArray(ngFamiliarCountLevel2);
            CopyBytesToArray(ngFamiliarCountLevel3);
            CopyBytesToArray(ngFamiliarCountLevel4);
            CopyBytesToArray(ngFamiliarCountLevel5);
            CopyBytesToArray(ngFamiliarCountLevel6);
            CopyBytesToArray(ngFamiliarCountLevel7);
            CopyBytesToArray(ngFamiliarCountLevel8);
            CopyBytesToArray(ngFamiliarCountLevel9);
            CopyBytesToArray(nnFamiliarCountLevel1);
            CopyBytesToArray(nnFamiliarCountLevel2);
            CopyBytesToArray(nnFamiliarCountLevel3);
            CopyBytesToArray(nnFamiliarCountLevel4);
            CopyBytesToArray(nnFamiliarCountLevel5);
            CopyBytesToArray(nnFamiliarCountLevel6);
            CopyBytesToArray(nnFamiliarCountLevel7);
            CopyBytesToArray(nnFamiliarCountLevel8);
            CopyBytesToArray(nnFamiliarCountLevel9);
            CopyBytesToArray(neFamiliarCountLevel1);
            CopyBytesToArray(neFamiliarCountLevel2);
            CopyBytesToArray(neFamiliarCountLevel3);
            CopyBytesToArray(neFamiliarCountLevel4);
            CopyBytesToArray(neFamiliarCountLevel5);
            CopyBytesToArray(neFamiliarCountLevel6);
            CopyBytesToArray(neFamiliarCountLevel7);
            CopyBytesToArray(neFamiliarCountLevel8);
            CopyBytesToArray(neFamiliarCountLevel9);
            CopyBytesToArray(cgFamiliarCountLevel1);
            CopyBytesToArray(cgFamiliarCountLevel2);
            CopyBytesToArray(cgFamiliarCountLevel3);
            CopyBytesToArray(cgFamiliarCountLevel4);
            CopyBytesToArray(cgFamiliarCountLevel5);
            CopyBytesToArray(cgFamiliarCountLevel6);
            CopyBytesToArray(cgFamiliarCountLevel7);
            CopyBytesToArray(cgFamiliarCountLevel8);
            CopyBytesToArray(cgFamiliarCountLevel9);
            CopyBytesToArray(cnFamiliarCountLevel1);
            CopyBytesToArray(cnFamiliarCountLevel2);
            CopyBytesToArray(cnFamiliarCountLevel3);
            CopyBytesToArray(cnFamiliarCountLevel4);
            CopyBytesToArray(cnFamiliarCountLevel5);
            CopyBytesToArray(cnFamiliarCountLevel6);
            CopyBytesToArray(cnFamiliarCountLevel7);
            CopyBytesToArray(cnFamiliarCountLevel8);
            CopyBytesToArray(cnFamiliarCountLevel9);
            CopyBytesToArray(ceFamiliarCountLevel1);
            CopyBytesToArray(ceFamiliarCountLevel2);
            CopyBytesToArray(ceFamiliarCountLevel3);
            CopyBytesToArray(ceFamiliarCountLevel4);
            CopyBytesToArray(ceFamiliarCountLevel5);
            CopyBytesToArray(ceFamiliarCountLevel6);
            CopyBytesToArray(ceFamiliarCountLevel7);
            CopyBytesToArray(ceFamiliarCountLevel8);
            CopyBytesToArray(ceFamiliarCountLevel9);
            
            return byteArray;
        }

        internal void CopyBytesToArray(double variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 8);
            arrayOffset += 8;
        }
        internal void CopyBytesToArray(String variable)
        {
            System.Buffer.BlockCopy(Encoding.ASCII.GetBytes(variable), 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(byte[] variable)
        {
            System.Buffer.BlockCopy(variable, 0, byteArray, arrayOffset, variable.Length);
            arrayOffset += variable.Length;
        }
        internal void CopyBytesToArray(int variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 4);
            arrayOffset += 4;
        }
        internal void CopyBytesToArray(short variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 2);
            arrayOffset += 2;
        }
        internal void CopyBytesToArray(byte variable)
        {
            System.Buffer.BlockCopy(BitConverter.GetBytes(variable), 0, byteArray, arrayOffset, 1);
            arrayOffset += 1;
        }
    }
}