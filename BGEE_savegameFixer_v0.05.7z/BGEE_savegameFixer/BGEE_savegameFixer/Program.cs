﻿using System;
using System.Collections;
using System.IO;
using BGEE_savegameFixer;

namespace BGEE_savegameFixer
{
    internal partial class Program
    {
        internal static byte[] gamByteArray;
        internal static byte[] savByteArray;

        // GAME OBJECTS
        
        internal static GamHeader gamHeader;
        internal static ArrayList gamNpcsParty;
        internal static ArrayList gamCreStructsParty;
        internal static ArrayList gamNpcsNonParty;
        internal static ArrayList gamCreStructsNonParty;
        internal static ArrayList gamVars;
        internal static ArrayList gamJournalEntries;
        internal static GamFamiliarInfo gamFamiliarInfo;
        internal static ArrayList gamStoredLocations;
        internal static ArrayList gamPocketPlaneInfos;

        internal static GamNpc currentGamNpc;
        internal static GamCreStruct currentGamCreStruct;
        internal static GamVar currentGamVar;
        internal static GamJournalEntry currentGamJournalEntry;
        internal static GamStoredLocationInfo currentGamStoredLocationInfo;
        internal static GamStoredLocationInfo currentGamPocketPlaneInfo;

        // SAVE OBJECTS
        
        internal static SavHeader savHeader;
        internal static ArrayList savElements;
        
        internal static SavElement CurrentSavElement;

        public static void Main(string[] args)
        {
            FileInfo[] gamFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "gam");
            FileInfo[] savFileInfos = FileOperations.GetAllSavegames(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save", "sav");
            
            // /////////// //
            // GAM EDITING //
            // /////////// //
            
            // foreach (FileInfo gamFile in gamFiles)
            // {
            //     Console.WriteLine("WORKING ON " + gamFile.FullName);
            //     CreateGamObjects(gamFile.FullName);
            //
            //     int viccyIndex = FindPartyCreIndex(@"*ICONI");
            //     try
            //     {
            //         currentCreStruct = (GamCreStruct) gamCreStructsParty[viccyIndex];
            //
            //         for (int i = 0; i < currentCreStruct.creKnownSpells.Count; i++)
            //         {
            //             CreKnownSpell currentKnownSpell = (CreKnownSpell) currentCreStruct.creKnownSpells[i];
            //             if (currentKnownSpell.resource.Contains("SPPR418"))
            //             {
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //                 currentCreStruct.creKnownSpells.RemoveAt(i);
            //                 currentCreStruct.creHeader.knownSpellsCount--;
            //                 currentCreStruct.creHeader.knownSpellsOffset -= 12;
            //                 // Console.WriteLine(currentCreStruct.creKnownSpells.Count);
            //             }
            //         }
            //
            //         gamCreStructsParty[viccyIndex] = currentCreStruct;
            //
            //         FileOperations.WriteFile(
            //             gamHeader,
            //             gamNpcsParty,
            //             gamCreStructsParty,
            //             gamNpcsNonParty,
            //             gamCreStructsNonParty,
            //             gamVars,
            //             gamJournalEntries,
            //             gamFamiliarInfo,
            //             gamStoredLocations,
            //             gamPocketPlaneInfos,
            //             gamFile.FullName);
            //     }
            //     catch (Exception ignore)
            //     {
            //         Console.WriteLine("Not found skipping...");
            //     }
            // }
            
            // /////////// //
            // SAV EDITING //
            // /////////// //
            
            foreach (FileInfo savFileInfo in savFileInfos)
            {
                Console.WriteLine("---------------------" + savFileInfo.FullName + "---------------------");
                
                CreateSavObjects(savFileInfo.FullName);
            
                Boolean found = false;
            
                foreach (SavElement savElement in savElements)
                {
                    savElement.Decompress();
                    if (savElement.filename.Contains("KEYR") && savElement.filename.Contains(".sto"))
                    {
                        found = true;
                        savElement.stoHeader.capacity = 50;
                        savElement.stoHeader.name = 304488;
                    }
                    savElement.Compress();
                }
                
                if (found)
                {
                    FileOperations.WriteFile(savHeader, savElements, savFileInfo.FullName);
                }
            }
            
            // CreateSavObjects(@"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save\000000000-10 - Before Davaeorn\BALDUR.sav");
            // foreach (SavElement savElement in savElements)
            // {
            //     if (savElement.filename.Contains("BG0500"))
            //     {
            //         
            //         Console.WriteLine(savElement.filename);
            //         // Console.WriteLine("BEFORE DECOMPRESS 1");
            //         savElement.Decompress();
            //         // foreach (SavCreStruct savCreStruct in savFile.savCreStructs)
            //         // {
            //         //     Console.WriteLine("decompress " + savCreStruct.creHeader.scriptName);
            //         // }
            //         // Console.WriteLine("BEFORE COMPRESS 1");
            //         // savElement.Compress();
            //         // foreach (SavCreStruct savCreStruct in savFile.savCreStructs)
            //         // {
            //         //     Console.WriteLine("compress " + savCreStruct.creHeader.scriptName);
            //         // }
            //         savElement.CreateObjects();
            //         savElement.CreateByteData();
            //         FileOperations.WriteFile(savElement.decompressedData, @"C:\Users\Simon\Documents\test\" + savElement.filename.Trim(Path.GetInvalidFileNameChars()));
            //         // FileOperations.WriteFile(savHeader, savFiles, @"C:\Users\Simon\Documents\Baldur's Gate - Enhanced Edition Trilogy\save\000000000-10 - Before Davaeorn\BALDUR2.sav");
            //         // Console.WriteLine("BEFORE DECOMPRESS 2");
            //         // savFile.Decompress();
            //         
            //     }
            // }
        }
    }
}